#!/usr/bin/env python3
import re

with open('generate_large_vocabulary.py', 'r', encoding='utf-8') as f:
    content = f.read()

# Fix all instances of 'word', ['syn1', 'syn2'] -> 'word': ['syn1', 'syn2']
pattern = r"'([a-z]+)', \["
replacement = r"'\1': ["
content = re.sub(pattern, replacement, content)

with open('generate_large_vocabulary.py', 'w', encoding='utf-8') as f:
    f.write(content)

print('Fixed all dictionary syntax errors')
