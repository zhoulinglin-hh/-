﻿// 四级核心词汇数据集（1000词）
// 包含：单词、音标、释义、词根衍生、近义词、反义词、例句、考频

const vocabularyData = [
  {
    "id": 1,
    "word": "abandon",
    "phonetic": "/abandon/",
    "definition": "v. 放弃，抛弃",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "desert",
      "forsake"
    ],
    "antonyms": [
      "retain",
      "keep"
    ],
    "example": "He abandoned his car in the snow.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 2,
    "word": "ability",
    "phonetic": "/ability/",
    "definition": "n. 能力，才能",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "capability",
      "capacity"
    ],
    "antonyms": [
      "inability",
      "disability"
    ],
    "example": "She has the ability to solve problems.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 3,
    "word": "absence",
    "phonetic": "/absence/",
    "definition": "n. 缺席，不在",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "His absence was noticed by everyone.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 4,
    "word": "absolute",
    "phonetic": "/absolute/",
    "definition": "adj. 绝对的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "relative"
    ],
    "example": "I have absolute confidence in you.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 5,
    "word": "absorb",
    "phonetic": "/absorb/",
    "definition": "v. 吸收",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "assimilate",
      "take in"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "Plants absorb carbon dioxide.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 6,
    "word": "abstract",
    "phonetic": "/abstract/",
    "definition": "adj. 抽象的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "concrete"
    ],
    "example": "Truth is an abstract concept.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 7,
    "word": "abundant",
    "phonetic": "/abundant/",
    "definition": "adj. 丰富的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "scarce"
    ],
    "example": "The region is abundant in resources.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 8,
    "word": "academic",
    "phonetic": "/academic/",
    "definition": "adj. 学术的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "She has an excellent academic record.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 9,
    "word": "accelerate",
    "phonetic": "/accelerate/",
    "definition": "v. 加速",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The car accelerated rapidly.",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 10,
    "word": "access",
    "phonetic": "/access/",
    "definition": "n. 通道；v. 访问",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "Students have access to online resources.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 11,
    "word": "accommodate",
    "phonetic": "/accommodate/",
    "definition": "v. 容纳，适应",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The hotel can accommodate 500 guests.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 12,
    "word": "accomplish",
    "phonetic": "/accomplish/",
    "definition": "v. 完成",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "She accomplished her mission successfully.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 13,
    "word": "accumulate",
    "phonetic": "/accumulate/",
    "definition": "v. 积累",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "Dust began to accumulate on the shelves.",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 14,
    "word": "accurate",
    "phonetic": "/accurate/",
    "definition": "adj. 精确的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "precise",
      "exact"
    ],
    "antonyms": [
      "inaccurate"
    ],
    "example": "The forecast was surprisingly accurate.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 15,
    "word": "accuse",
    "phonetic": "/accuse/",
    "definition": "v. 指控",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "He was accused of stealing money.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 16,
    "word": "achieve",
    "phonetic": "/achieve/",
    "definition": "v. 达到，实现",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "accomplish",
      "attain"
    ],
    "antonyms": [
      "fail"
    ],
    "example": "She worked hard to achieve her goals.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 17,
    "word": "acknowledge",
    "phonetic": "/acknowledge/",
    "definition": "v. 承认",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "He refused to acknowledge his mistake.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 18,
    "word": "acquire",
    "phonetic": "/acquire/",
    "definition": "v. 获得",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "obtain",
      "gain"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "She acquired valuable skills.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 19,
    "word": "adequate",
    "phonetic": "/adequate/",
    "definition": "adj. 足够的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "sufficient",
      "enough"
    ],
    "antonyms": [
      "inadequate"
    ],
    "example": "The food supply is adequate.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 20,
    "word": "adjust",
    "phonetic": "/adjust/",
    "definition": "v. 调整",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "adapt",
      "modify"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "It takes time to adjust to a new environment.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 21,
    "word": "administration",
    "phonetic": "/administration/",
    "definition": "n. 管理",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The administration needs improvement.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 22,
    "word": "admire",
    "phonetic": "/admire/",
    "definition": "v. 钦佩",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "I really admire her dedication.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 23,
    "word": "admit",
    "phonetic": "/admit/",
    "definition": "v. 承认",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "deny"
    ],
    "example": "He admitted that he had made a mistake.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 24,
    "word": "adopt",
    "phonetic": "/adopt/",
    "definition": "v. 采用，收养",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The company decided to adopt new technology.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 25,
    "word": "advance",
    "phonetic": "/advance/",
    "definition": "v. 前进",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "retreat"
    ],
    "example": "Medical science has made great advances.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 26,
    "word": "advantage",
    "phonetic": "/advantage/",
    "definition": "n. 优势",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "benefit",
      "merit"
    ],
    "antonyms": [
      "disadvantage"
    ],
    "example": "Her experience gives her an advantage.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 27,
    "word": "advertise",
    "phonetic": "/advertise/",
    "definition": "v. 做广告",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "They advertised the product on TV.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 28,
    "word": "advice",
    "phonetic": "/advice/",
    "definition": "n. 建议",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "suggestion",
      "recommendation"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "Can you give me some advice?",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 29,
    "word": "advocate",
    "phonetic": "/advocate/",
    "definition": "v. 提倡",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "She advocates for equal rights.",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 30,
    "word": "affect",
    "phonetic": "/affect/",
    "definition": "v. 影响",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "influence",
      "impact"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The weather can affect people's mood.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 31,
    "word": "afford",
    "phonetic": "/afford/",
    "definition": "v. 负担得起",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "I can't afford to buy a new car.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 32,
    "word": "afraid",
    "phonetic": "/afraid/",
    "definition": "adj. 害怕的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "scared",
      "frightened"
    ],
    "antonyms": [
      "brave"
    ],
    "example": "Don't be afraid to ask questions.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 33,
    "word": "agency",
    "phonetic": "/agency/",
    "definition": "n. 代理，机构",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "She works for a travel agency.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 34,
    "word": "agenda",
    "phonetic": "/agenda/",
    "definition": "n. 议程",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "What's on the agenda for today?",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 35,
    "word": "aggressive",
    "phonetic": "/aggressive/",
    "definition": "adj. 侵略性的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The company adopted an aggressive strategy.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 36,
    "word": "agree",
    "phonetic": "/agree/",
    "definition": "v. 同意",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "consent",
      "approve"
    ],
    "antonyms": [
      "disagree"
    ],
    "example": "Do you agree with his opinion?",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 37,
    "word": "aid",
    "phonetic": "/aid/",
    "definition": "n./v. 帮助",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "help",
      "assist"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The government provided financial aid.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 38,
    "word": "alarm",
    "phonetic": "/alarm/",
    "definition": "n. 警报",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The fire alarm went off.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 39,
    "word": "alert",
    "phonetic": "/alert/",
    "definition": "adj. 警觉的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "Drivers must stay alert at all times.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 40,
    "word": "allocate",
    "phonetic": "/allocate/",
    "definition": "v. 分配",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The government will allocate funds.",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 41,
    "word": "allow",
    "phonetic": "/allow/",
    "definition": "v. 允许",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "permit",
      "let"
    ],
    "antonyms": [
      "forbid"
    ],
    "example": "Pets are not allowed in the building.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 42,
    "word": "alter",
    "phonetic": "/alter/",
    "definition": "v. 改变",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "change",
      "modify"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "I need to alter my plans.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 43,
    "word": "alternative",
    "phonetic": "/alternative/",
    "definition": "adj. 可选择的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "We need to find an alternative solution.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 44,
    "word": "amateur",
    "phonetic": "/amateur/",
    "definition": "n. 业余爱好者",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "He's an amateur photographer.",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 45,
    "word": "amaze",
    "phonetic": "/amaze/",
    "definition": "v. 使惊奇",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "astonish",
      "surprise"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "Her performance amazed the audience.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 46,
    "word": "ambition",
    "phonetic": "/ambition/",
    "definition": "n. 雄心",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "aspiration",
      "goal"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "His ambition is to become a doctor.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 47,
    "word": "amend",
    "phonetic": "/amend/",
    "definition": "v. 修改",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The constitution was amended.",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 48,
    "word": "amount",
    "phonetic": "/amount/",
    "definition": "n. 数量",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "quantity",
      "sum"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The total amount comes to $500.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 49,
    "word": "amuse",
    "phonetic": "/amuse/",
    "definition": "v. 使娱乐",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "The clown amused the children.",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 50,
    "word": "analyze",
    "phonetic": "/analyze/",
    "definition": "v. 分析",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "examine",
      "study"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "We need to analyze the data.",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 51,
    "word": "announce",
    "phonetic": "/announce/",
    "definition": "v. 宣布",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "declare",
      "proclaim"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"announce\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 52,
    "word": "annoy",
    "phonetic": "/annoy/",
    "definition": "v. 使烦恼",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "irritate",
      "bother"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"annoy\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 53,
    "word": "annual",
    "phonetic": "/annual/",
    "definition": "adj. 每年的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"annual\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 54,
    "word": "anticipate",
    "phonetic": "/anticipate/",
    "definition": "v. 预期",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"anticipate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 55,
    "word": "anxiety",
    "phonetic": "/anxiety/",
    "definition": "n. 焦虑",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "worry",
      "concern"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"anxiety\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 56,
    "word": "apologize",
    "phonetic": "/apologize/",
    "definition": "v. 道歉",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "say sorry"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"apologize\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 57,
    "word": "apparent",
    "phonetic": "/apparent/",
    "definition": "adj. 明显的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "obvious",
      "clear"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"apparent\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 58,
    "word": "appeal",
    "phonetic": "/appeal/",
    "definition": "v. 吸引，呼吁",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"appeal\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 59,
    "word": "appear",
    "phonetic": "/appear/",
    "definition": "v. 出现",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "seem",
      "look"
    ],
    "antonyms": [
      "disappear"
    ],
    "example": "This is an example sentence using the word \"appear\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 60,
    "word": "appetite",
    "phonetic": "/appetite/",
    "definition": "n. 食欲",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"appetite\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 61,
    "word": "applaud",
    "phonetic": "/applaud/",
    "definition": "v. 鼓掌",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"applaud\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 62,
    "word": "apply",
    "phonetic": "/apply/",
    "definition": "v. 申请，应用",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "use",
      "employ"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"apply\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 63,
    "word": "appoint",
    "phonetic": "/appoint/",
    "definition": "v. 任命",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"appoint\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 64,
    "word": "appreciate",
    "phonetic": "/appreciate/",
    "definition": "v. 欣赏，感激",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "value",
      "cherish"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"appreciate\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 65,
    "word": "approach",
    "phonetic": "/approach/",
    "definition": "v. 接近",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "method",
      "way"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"approach\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 66,
    "word": "appropriate",
    "phonetic": "/appropriate/",
    "definition": "adj. 适当的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "suitable",
      "proper"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"appropriate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 67,
    "word": "approve",
    "phonetic": "/approve/",
    "definition": "v. 赞成",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "agree",
      "accept"
    ],
    "antonyms": [
      "disapprove"
    ],
    "example": "This is an example sentence using the word \"approve\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 68,
    "word": "approximate",
    "phonetic": "/approximate/",
    "definition": "adj. 近似的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"approximate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 69,
    "word": "arbitrary",
    "phonetic": "/arbitrary/",
    "definition": "adj. 任意的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"arbitrary\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 70,
    "word": "argue",
    "phonetic": "/argue/",
    "definition": "v. 争论",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "debate",
      "dispute"
    ],
    "antonyms": [
      "agree"
    ],
    "example": "This is an example sentence using the word \"argue\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 71,
    "word": "arise",
    "phonetic": "/arise/",
    "definition": "v. 出现",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"arise\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 72,
    "word": "arrange",
    "phonetic": "/arrange/",
    "definition": "v. 安排",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "organize",
      "plan"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"arrange\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 73,
    "word": "arrest",
    "phonetic": "/arrest/",
    "definition": "v. 逮捕",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"arrest\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 74,
    "word": "arrive",
    "phonetic": "/arrive/",
    "definition": "v. 到达",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "reach",
      "get to"
    ],
    "antonyms": [
      "depart"
    ],
    "example": "This is an example sentence using the word \"arrive\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 75,
    "word": "article",
    "phonetic": "/article/",
    "definition": "n. 文章",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "essay",
      "piece"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"article\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 76,
    "word": "artificial",
    "phonetic": "/artificial/",
    "definition": "adj. 人造的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "natural"
    ],
    "example": "This is an example sentence using the word \"artificial\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 77,
    "word": "ashamed",
    "phonetic": "/ashamed/",
    "definition": "adj. 惭愧的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "embarrassed",
      "guilty"
    ],
    "antonyms": [
      "proud"
    ],
    "example": "This is an example sentence using the word \"ashamed\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 78,
    "word": "aspect",
    "phonetic": "/aspect/",
    "definition": "n. 方面",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "facet",
      "side"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"aspect\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 79,
    "word": "assemble",
    "phonetic": "/assemble/",
    "definition": "v. 集合",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"assemble\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 80,
    "word": "assess",
    "phonetic": "/assess/",
    "definition": "v. 评估",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"assess\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 81,
    "word": "assign",
    "phonetic": "/assign/",
    "definition": "v. 分配",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"assign\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 82,
    "word": "assist",
    "phonetic": "/assist/",
    "definition": "v. 协助",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "help",
      "aid"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"assist\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 83,
    "word": "associate",
    "phonetic": "/associate/",
    "definition": "v. 联系",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"associate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 84,
    "word": "assume",
    "phonetic": "/assume/",
    "definition": "v. 假设",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "suppose",
      "presume"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"assume\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 85,
    "word": "assure",
    "phonetic": "/assure/",
    "definition": "v. 保证",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "ensure",
      "guarantee"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"assure\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 86,
    "word": "attach",
    "phonetic": "/attach/",
    "definition": "v. 附上",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "connect",
      "fasten"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"attach\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 87,
    "word": "attack",
    "phonetic": "/attack/",
    "definition": "v. 攻击",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "assault",
      "strike"
    ],
    "antonyms": [
      "defend"
    ],
    "example": "This is an example sentence using the word \"attack\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 88,
    "word": "attempt",
    "phonetic": "/attempt/",
    "definition": "v. 尝试",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "try",
      "endeavor"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"attempt\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 89,
    "word": "attend",
    "phonetic": "/attend/",
    "definition": "v. 参加",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"attend\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 90,
    "word": "attract",
    "phonetic": "/attract/",
    "definition": "v. 吸引",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "appeal",
      "draw"
    ],
    "antonyms": [
      "repel"
    ],
    "example": "This is an example sentence using the word \"attract\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 91,
    "word": "attribute",
    "phonetic": "/attribute/",
    "definition": "v. 归因于",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"attribute\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 92,
    "word": "authority",
    "phonetic": "/authority/",
    "definition": "n. 权威",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"authority\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 93,
    "word": "automatic",
    "phonetic": "/automatic/",
    "definition": "adj. 自动的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"automatic\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 94,
    "word": "available",
    "phonetic": "/available/",
    "definition": "adj. 可用的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"available\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 95,
    "word": "avoid",
    "phonetic": "/avoid/",
    "definition": "v. 避免",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "evade",
      "escape"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"avoid\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 96,
    "word": "award",
    "phonetic": "/award/",
    "definition": "n. 奖",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "prize",
      "reward"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"award\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 97,
    "word": "aware",
    "phonetic": "/aware/",
    "definition": "adj. 意识到的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "conscious",
      "mindful"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"aware\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 98,
    "word": "awful",
    "phonetic": "/awful/",
    "definition": "adj. 可怕的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "terrible",
      "dreadful"
    ],
    "antonyms": [
      "wonderful"
    ],
    "example": "This is an example sentence using the word \"awful\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 99,
    "word": "awkward",
    "phonetic": "/awkward/",
    "definition": "adj. 尴尬的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"awkward\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 100,
    "word": "background",
    "phonetic": "/background/",
    "definition": "n. 背景",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"background\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 101,
    "word": "balance",
    "phonetic": "/balance/",
    "definition": "n. 平衡",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "equilibrium",
      "stability"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"balance\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 102,
    "word": "ban",
    "phonetic": "/ban/",
    "definition": "v. 禁止",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "prohibit",
      "forbid"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"ban\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 103,
    "word": "barely",
    "phonetic": "/barely/",
    "definition": "adv. 几乎不",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"barely\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 104,
    "word": "bargain",
    "phonetic": "/bargain/",
    "definition": "n. 交易",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bargain\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 105,
    "word": "barrier",
    "phonetic": "/barrier/",
    "definition": "n. 障碍",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"barrier\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 106,
    "word": "base",
    "phonetic": "/base/",
    "definition": "n. 基础",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "foundation",
      "basis"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"base\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 107,
    "word": "basic",
    "phonetic": "/basic/",
    "definition": "adj. 基本的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "fundamental",
      "essential"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"basic\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 108,
    "word": "basis",
    "phonetic": "/basis/",
    "definition": "n. 基础",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"basis\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 109,
    "word": "bear",
    "phonetic": "/bear/",
    "definition": "v. 忍受",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "endure",
      "tolerate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bear\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 110,
    "word": "beat",
    "phonetic": "/beat/",
    "definition": "v. 打败",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "defeat",
      "overcome"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"beat\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 111,
    "word": "behave",
    "phonetic": "/behave/",
    "definition": "v. 表现",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "act",
      "conduct"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"behave\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 112,
    "word": "behavior",
    "phonetic": "/behavior/",
    "definition": "n. 行为",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"behavior\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 113,
    "word": "belief",
    "phonetic": "/belief/",
    "definition": "n. 信念",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "faith",
      "conviction"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"belief\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 114,
    "word": "belong",
    "phonetic": "/belong/",
    "definition": "v. 属于",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "fit",
      "appertain"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"belong\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 115,
    "word": "benefit",
    "phonetic": "/benefit/",
    "definition": "n. 益处",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "advantage",
      "profit"
    ],
    "antonyms": [
      "harm"
    ],
    "example": "This is an example sentence using the word \"benefit\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 116,
    "word": "betray",
    "phonetic": "/betray/",
    "definition": "v. 背叛",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"betray\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 117,
    "word": "beyond",
    "phonetic": "/beyond/",
    "definition": "prep. 超出",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "past",
      "above"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"beyond\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 118,
    "word": "bind",
    "phonetic": "/bind/",
    "definition": "v. 捆绑",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "tie",
      "fasten"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bind\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 119,
    "word": "bitter",
    "phonetic": "/bitter/",
    "definition": "adj. 苦的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "sweet"
    ],
    "example": "This is an example sentence using the word \"bitter\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 120,
    "word": "blame",
    "phonetic": "/blame/",
    "definition": "v. 责备",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "fault",
      "criticize"
    ],
    "antonyms": [
      "praise"
    ],
    "example": "This is an example sentence using the word \"blame\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 121,
    "word": "blank",
    "phonetic": "/blank/",
    "definition": "adj. 空白的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"blank\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 122,
    "word": "blind",
    "phonetic": "/blind/",
    "definition": "adj. 盲目的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"blind\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 123,
    "word": "block",
    "phonetic": "/block/",
    "definition": "v. 阻挡",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "obstruct",
      "hinder"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"block\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 124,
    "word": "bloom",
    "phonetic": "/bloom/",
    "definition": "v. 开花",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bloom\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 125,
    "word": "board",
    "phonetic": "/board/",
    "definition": "n. 板，董事会",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "panel",
      "committee"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"board\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 126,
    "word": "boast",
    "phonetic": "/boast/",
    "definition": "v. 自夸",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"boast\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 127,
    "word": "bold",
    "phonetic": "/bold/",
    "definition": "adj. 大胆的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "timid"
    ],
    "example": "This is an example sentence using the word \"bold\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 128,
    "word": "bomb",
    "phonetic": "/bomb/",
    "definition": "n. 炸弹",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bomb\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 129,
    "word": "border",
    "phonetic": "/border/",
    "definition": "n. 边界",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"border\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 130,
    "word": "bore",
    "phonetic": "/bore/",
    "definition": "v. 使厌烦",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bore\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 131,
    "word": "bother",
    "phonetic": "/bother/",
    "definition": "v. 打扰",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "disturb",
      "annoy"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bother\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 132,
    "word": "bound",
    "phonetic": "/bound/",
    "definition": "adj. 一定的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bound\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 133,
    "word": "boundary",
    "phonetic": "/boundary/",
    "definition": "n. 分界线",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "border",
      "limit"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"boundary\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 134,
    "word": "brake",
    "phonetic": "/brake/",
    "definition": "n. 刹车",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"brake\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 135,
    "word": "branch",
    "phonetic": "/branch/",
    "definition": "n. 分支",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "division",
      "section"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"branch\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 136,
    "word": "brand",
    "phonetic": "/brand/",
    "definition": "n. 品牌",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "label",
      "trademark"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"brand\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 137,
    "word": "breed",
    "phonetic": "/breed/",
    "definition": "v. 繁殖",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"breed\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 138,
    "word": "brief",
    "phonetic": "/brief/",
    "definition": "adj. 简短的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "short",
      "concise"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"brief\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 139,
    "word": "brilliant",
    "phonetic": "/brilliant/",
    "definition": "adj. 杰出的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "bright",
      "outstanding"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"brilliant\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 140,
    "word": "broadcast",
    "phonetic": "/broadcast/",
    "definition": "v. 广播",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"broadcast\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 141,
    "word": "budget",
    "phonetic": "/budget/",
    "definition": "n. 预算",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "finance",
      "fund"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"budget\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 142,
    "word": "bulk",
    "phonetic": "/bulk/",
    "definition": "n. 大量",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"bulk\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 143,
    "word": "burden",
    "phonetic": "/burden/",
    "definition": "n. 负担",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "load",
      "weight"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"burden\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 144,
    "word": "burst",
    "phonetic": "/burst/",
    "definition": "v. 爆发",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"burst\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 145,
    "word": "cable",
    "phonetic": "/cable/",
    "definition": "n. 电缆",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cable\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 146,
    "word": "calculate",
    "phonetic": "/calculate/",
    "definition": "v. 计算",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "compute",
      "figure"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"calculate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 147,
    "word": "campaign",
    "phonetic": "/campaign/",
    "definition": "n. 运动",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "movement",
      "drive"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"campaign\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 148,
    "word": "cancel",
    "phonetic": "/cancel/",
    "definition": "v. 取消",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "abolish",
      "call off"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cancel\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 149,
    "word": "candidate",
    "phonetic": "/candidate/",
    "definition": "n. 候选人",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"candidate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 150,
    "word": "capable",
    "phonetic": "/capable/",
    "definition": "adj. 有能力的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "able",
      "competent"
    ],
    "antonyms": [
      "incapable"
    ],
    "example": "This is an example sentence using the word \"capable\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 151,
    "word": "capacity",
    "phonetic": "/capacity/",
    "definition": "n. 容量",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "ability",
      "capability"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"capacity\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 152,
    "word": "capture",
    "phonetic": "/capture/",
    "definition": "v. 捕获",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"capture\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 153,
    "word": "career",
    "phonetic": "/career/",
    "definition": "n. 职业",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "profession",
      "occupation"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"career\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 154,
    "word": "careless",
    "phonetic": "/careless/",
    "definition": "adj. 粗心的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "negligent",
      "reckless"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"careless\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 155,
    "word": "casual",
    "phonetic": "/casual/",
    "definition": "adj. 随便的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "informal",
      "relaxed"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"casual\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 156,
    "word": "category",
    "phonetic": "/category/",
    "definition": "n. 类别",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "class",
      "group"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"category\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 157,
    "word": "cautious",
    "phonetic": "/cautious/",
    "definition": "adj. 谨慎的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "careful",
      "wary"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cautious\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 158,
    "word": "cease",
    "phonetic": "/cease/",
    "definition": "v. 停止",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "continue"
    ],
    "example": "This is an example sentence using the word \"cease\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 159,
    "word": "celebrate",
    "phonetic": "/celebrate/",
    "definition": "v. 庆祝",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "observe",
      "commemorate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"celebrate\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 160,
    "word": "challenge",
    "phonetic": "/challenge/",
    "definition": "n. 挑战",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "defy",
      "dare"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"challenge\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 161,
    "word": "champion",
    "phonetic": "/champion/",
    "definition": "n. 冠军",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "winner",
      "hero"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"champion\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 162,
    "word": "channel",
    "phonetic": "/channel/",
    "definition": "n. 频道",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "route",
      "pathway"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"channel\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 163,
    "word": "chaos",
    "phonetic": "/chaos/",
    "definition": "n. 混乱",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"chaos\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 164,
    "word": "character",
    "phonetic": "/character/",
    "definition": "n. 性格，角色",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "nature",
      "personality"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"character\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 165,
    "word": "characteristic",
    "phonetic": "/characteristic/",
    "definition": "n. 特征",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"characteristic\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 166,
    "word": "charge",
    "phonetic": "/charge/",
    "definition": "v. 收费，指控",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "fee",
      "cost"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"charge\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 167,
    "word": "charity",
    "phonetic": "/charity/",
    "definition": "n. 慈善",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "philanthropy",
      "aid"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"charity\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 168,
    "word": "charm",
    "phonetic": "/charm/",
    "definition": "n. 魅力",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "appeal",
      "attraction"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"charm\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 169,
    "word": "chase",
    "phonetic": "/chase/",
    "definition": "v. 追逐",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "pursue",
      "follow"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"chase\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 170,
    "word": "cheat",
    "phonetic": "/cheat/",
    "definition": "v. 欺骗",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "deceive",
      "trick"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cheat\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 171,
    "word": "check",
    "phonetic": "/check/",
    "definition": "v. 检查",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "examine",
      "verify"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"check\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 172,
    "word": "cheerful",
    "phonetic": "/cheerful/",
    "definition": "adj. 愉快的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "sad"
    ],
    "example": "This is an example sentence using the word \"cheerful\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 173,
    "word": "chemical",
    "phonetic": "/chemical/",
    "definition": "adj. 化学的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "synthetic"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"chemical\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 174,
    "word": "cherish",
    "phonetic": "/cherish/",
    "definition": "v. 珍惜",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cherish\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 175,
    "word": "chief",
    "phonetic": "/chief/",
    "definition": "adj. 主要的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "main",
      "principal"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"chief\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 176,
    "word": "choice",
    "phonetic": "/choice/",
    "definition": "n. 选择",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "option",
      "selection"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"choice\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 177,
    "word": "circumstance",
    "phonetic": "/circumstance/",
    "definition": "n. 环境",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "condition",
      "situation"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"circumstance\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 178,
    "word": "cite",
    "phonetic": "/cite/",
    "definition": "v. 引用",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "quote",
      "mention"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cite\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 179,
    "word": "civil",
    "phonetic": "/civil/",
    "definition": "adj. 公民的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "polite",
      "civic"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"civil\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 180,
    "word": "claim",
    "phonetic": "/claim/",
    "definition": "v. 声称",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "assert",
      "maintain"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"claim\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 181,
    "word": "clarify",
    "phonetic": "/clarify/",
    "definition": "v. 澄清",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "explain",
      "clear up"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"clarify\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 182,
    "word": "classic",
    "phonetic": "/classic/",
    "definition": "adj. 经典的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "typical",
      "standard"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"classic\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 183,
    "word": "classify",
    "phonetic": "/classify/",
    "definition": "v. 分类",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "categorize",
      "sort"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"classify\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 184,
    "word": "clue",
    "phonetic": "/clue/",
    "definition": "n. 线索",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "hint",
      "evidence"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"clue\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 185,
    "word": "coach",
    "phonetic": "/coach/",
    "definition": "n. 教练",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "train",
      "instruct"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"coach\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 186,
    "word": "coarse",
    "phonetic": "/coarse/",
    "definition": "adj. 粗糙的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"coarse\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 187,
    "word": "code",
    "phonetic": "/code/",
    "definition": "n. 密码，代码",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "cipher",
      "law"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"code\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 188,
    "word": "collapse",
    "phonetic": "/collapse/",
    "definition": "v. 倒塌",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "fall",
      "break down"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"collapse\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 189,
    "word": "colleague",
    "phonetic": "/colleague/",
    "definition": "n. 同事",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "coworker",
      "peer"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"colleague\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 190,
    "word": "collect",
    "phonetic": "/collect/",
    "definition": "v. 收集",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "gather",
      "assemble"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"collect\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 191,
    "word": "collision",
    "phonetic": "/collision/",
    "definition": "n. 碰撞",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"collision\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 192,
    "word": "combine",
    "phonetic": "/combine/",
    "definition": "v. 结合",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "merge",
      "integrate"
    ],
    "antonyms": [
      "separate"
    ],
    "example": "This is an example sentence using the word \"combine\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 193,
    "word": "comfort",
    "phonetic": "/comfort/",
    "definition": "n. 舒适",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "ease",
      "relief"
    ],
    "antonyms": [
      "discomfort"
    ],
    "example": "This is an example sentence using the word \"comfort\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 194,
    "word": "command",
    "phonetic": "/command/",
    "definition": "v. 命令",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "order",
      "direct"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"command\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 195,
    "word": "comment",
    "phonetic": "/comment/",
    "definition": "n. 评论",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "remark",
      "observation"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"comment\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 196,
    "word": "commerce",
    "phonetic": "/commerce/",
    "definition": "n. 商业",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"commerce\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 197,
    "word": "commercial",
    "phonetic": "/commercial/",
    "definition": "adj. 商业的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "business",
      "trade"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"commercial\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 198,
    "word": "commit",
    "phonetic": "/commit/",
    "definition": "v. 犯罪，承诺",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "pledge",
      "dedicate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"commit\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 199,
    "word": "communication",
    "phonetic": "/communication/",
    "definition": "n. 交流",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "transmission",
      "exchange"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"communication\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 200,
    "word": "community",
    "phonetic": "/community/",
    "definition": "n. 社区",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "society",
      "neighborhood"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"community\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 201,
    "word": "companion",
    "phonetic": "/companion/",
    "definition": "n. 同伴",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"companion\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 202,
    "word": "compare",
    "phonetic": "/compare/",
    "definition": "v. 比较",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "contrast",
      "liken"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"compare\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 203,
    "word": "compete",
    "phonetic": "/compete/",
    "definition": "v. 竞争",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "contend",
      "rival"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"compete\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 204,
    "word": "competent",
    "phonetic": "/competent/",
    "definition": "adj. 有能力的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "capable",
      "skilled"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"competent\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 205,
    "word": "competition",
    "phonetic": "/competition/",
    "definition": "n. 竞争",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "contest",
      "rivalry"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"competition\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 206,
    "word": "complain",
    "phonetic": "/complain/",
    "definition": "v. 抱怨",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "grumble",
      "protest"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"complain\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 207,
    "word": "complete",
    "phonetic": "/complete/",
    "definition": "adj. 完整的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "entire",
      "whole"
    ],
    "antonyms": [
      "incomplete"
    ],
    "example": "This is an example sentence using the word \"complete\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 208,
    "word": "complex",
    "phonetic": "/complex/",
    "definition": "adj. 复杂的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "complicated",
      "intricate"
    ],
    "antonyms": [
      "simple"
    ],
    "example": "This is an example sentence using the word \"complex\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 209,
    "word": "complicated",
    "phonetic": "/complicated/",
    "definition": "adj. 复杂的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"complicated\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 210,
    "word": "component",
    "phonetic": "/component/",
    "definition": "n. 组成部分",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "part",
      "element"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"component\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 211,
    "word": "compose",
    "phonetic": "/compose/",
    "definition": "v. 组成",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "create",
      "formulate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"compose\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 212,
    "word": "comprehensive",
    "phonetic": "/comprehensive/",
    "definition": "adj. 综合的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"comprehensive\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 213,
    "word": "compromise",
    "phonetic": "/compromise/",
    "definition": "n. 妥协",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "settlement",
      "concession"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"compromise\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 214,
    "word": "compulsory",
    "phonetic": "/compulsory/",
    "definition": "adj. 强制的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"compulsory\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 215,
    "word": "conceal",
    "phonetic": "/conceal/",
    "definition": "v. 隐藏",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "hide",
      "cover"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conceal\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 216,
    "word": "concede",
    "phonetic": "/concede/",
    "definition": "v. 承认",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"concede\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 217,
    "word": "concentrate",
    "phonetic": "/concentrate/",
    "definition": "v. 集中",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "focus",
      "center"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"concentrate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 218,
    "word": "concept",
    "phonetic": "/concept/",
    "definition": "n. 概念",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "idea",
      "notion"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"concept\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 219,
    "word": "concern",
    "phonetic": "/concern/",
    "definition": "v. 关心",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "worry",
      "interest"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"concern\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 220,
    "word": "conclude",
    "phonetic": "/conclude/",
    "definition": "v. 得出结论",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "finish",
      "infer"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conclude\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 221,
    "word": "concrete",
    "phonetic": "/concrete/",
    "definition": "adj. 具体的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "specific",
      "tangible"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"concrete\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 222,
    "word": "condemn",
    "phonetic": "/condemn/",
    "definition": "v. 谴责",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"condemn\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 223,
    "word": "condition",
    "phonetic": "/condition/",
    "definition": "n. 条件",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "state",
      "situation"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"condition\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 224,
    "word": "conduct",
    "phonetic": "/conduct/",
    "definition": "v. 进行",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "behavior",
      "manage"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conduct\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 225,
    "word": "conference",
    "phonetic": "/conference/",
    "definition": "n. 会议",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "meeting",
      "convention"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conference\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 226,
    "word": "confess",
    "phonetic": "/confess/",
    "definition": "v. 坦白",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "admit",
      "acknowledge"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"confess\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 227,
    "word": "confidence",
    "phonetic": "/confidence/",
    "definition": "n. 信心",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "trust",
      "assurance"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"confidence\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 228,
    "word": "confine",
    "phonetic": "/confine/",
    "definition": "v. 限制",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "limit",
      "restrict"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"confine\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 229,
    "word": "confirm",
    "phonetic": "/confirm/",
    "definition": "v. 证实",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "verify",
      "validate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"confirm\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 230,
    "word": "conflict",
    "phonetic": "/conflict/",
    "definition": "n. 冲突",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "clash",
      "dispute"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conflict\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 231,
    "word": "conform",
    "phonetic": "/conform/",
    "definition": "v. 符合",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conform\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 232,
    "word": "confront",
    "phonetic": "/confront/",
    "definition": "v. 面对",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"confront\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 233,
    "word": "confuse",
    "phonetic": "/confuse/",
    "definition": "v. 使困惑",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "puzzle",
      "bewilder"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"confuse\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 234,
    "word": "congratulate",
    "phonetic": "/congratulate/",
    "definition": "v. 祝贺",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"congratulate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 235,
    "word": "connect",
    "phonetic": "/connect/",
    "definition": "v. 连接",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "link",
      "join"
    ],
    "antonyms": [
      "disconnect"
    ],
    "example": "This is an example sentence using the word \"connect\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 236,
    "word": "conquer",
    "phonetic": "/conquer/",
    "definition": "v. 征服",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "defeat",
      "overcome"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conquer\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 237,
    "word": "conscience",
    "phonetic": "/conscience/",
    "definition": "n. 良心",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conscience\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 238,
    "word": "conscious",
    "phonetic": "/conscious/",
    "definition": "adj. 有意识的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "aware",
      "awake"
    ],
    "antonyms": [
      "unconscious"
    ],
    "example": "This is an example sentence using the word \"conscious\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 239,
    "word": "consensus",
    "phonetic": "/consensus/",
    "definition": "n. 共识",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consensus\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 240,
    "word": "consent",
    "phonetic": "/consent/",
    "definition": "v. 同意",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "agree",
      "permit"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consent\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 241,
    "word": "consequence",
    "phonetic": "/consequence/",
    "definition": "n. 结果",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "result",
      "outcome"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consequence\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 242,
    "word": "consequently",
    "phonetic": "/consequently/",
    "definition": "adv. 因此",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consequently\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 243,
    "word": "conservative",
    "phonetic": "/conservative/",
    "definition": "adj. 保守的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "traditional",
      "cautious"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conservative\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 244,
    "word": "consider",
    "phonetic": "/consider/",
    "definition": "v. 考虑",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "contemplate",
      "regard"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consider\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 245,
    "word": "considerable",
    "phonetic": "/considerable/",
    "definition": "adj. 相当大的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "significant",
      "substantial"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"considerable\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 246,
    "word": "considerate",
    "phonetic": "/considerate/",
    "definition": "adj. 体贴的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "thoughtful",
      "kind"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"considerate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 247,
    "word": "consist",
    "phonetic": "/consist/",
    "definition": "v. 由...组成",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "comprise",
      "compose"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consist\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 248,
    "word": "consistent",
    "phonetic": "/consistent/",
    "definition": "adj. 一致的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "coherent",
      "uniform"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consistent\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 249,
    "word": "constant",
    "phonetic": "/constant/",
    "definition": "adj. 不断的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "continual",
      "persistent"
    ],
    "antonyms": [
      "variable"
    ],
    "example": "This is an example sentence using the word \"constant\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 250,
    "word": "constitute",
    "phonetic": "/constitute/",
    "definition": "v. 构成",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"constitute\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 251,
    "word": "construct",
    "phonetic": "/construct/",
    "definition": "v. 建造",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "build",
      "erect"
    ],
    "antonyms": [
      "destroy"
    ],
    "example": "This is an example sentence using the word \"construct\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 252,
    "word": "consult",
    "phonetic": "/consult/",
    "definition": "v. 咨询",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "refer to",
      "ask"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consult\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 253,
    "word": "consume",
    "phonetic": "/consume/",
    "definition": "v. 消耗",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "use up",
      "devour"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"consume\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 254,
    "word": "contact",
    "phonetic": "/contact/",
    "definition": "n. 联系",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "touch",
      "reach"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"contact\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 255,
    "word": "contain",
    "phonetic": "/contain/",
    "definition": "v. 包含",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "include",
      "hold"
    ],
    "antonyms": [
      "exclude"
    ],
    "example": "This is an example sentence using the word \"contain\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 256,
    "word": "contemporary",
    "phonetic": "/contemporary/",
    "definition": "adj. 当代的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "modern",
      "current"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"contemporary\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 257,
    "word": "contempt",
    "phonetic": "/contempt/",
    "definition": "n. 轻视",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"contempt\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 258,
    "word": "content",
    "phonetic": "/content/",
    "definition": "n. 内容",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "satisfied",
      "pleased"
    ],
    "antonyms": [
      "discontent"
    ],
    "example": "This is an example sentence using the word \"content\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 259,
    "word": "contest",
    "phonetic": "/contest/",
    "definition": "n. 比赛",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "competition",
      "match"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"contest\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 260,
    "word": "context",
    "phonetic": "/context/",
    "definition": "n. 上下文",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "background",
      "setting"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"context\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 261,
    "word": "continual",
    "phonetic": "/continual/",
    "definition": "adj. 不断的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"continual\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 262,
    "word": "continuous",
    "phonetic": "/continuous/",
    "definition": "adj. 连续的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"continuous\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 263,
    "word": "contract",
    "phonetic": "/contract/",
    "definition": "n. 合同",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "agreement",
      "shrink"
    ],
    "antonyms": [
      "expand"
    ],
    "example": "This is an example sentence using the word \"contract\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 264,
    "word": "contradict",
    "phonetic": "/contradict/",
    "definition": "v. 反驳",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"contradict\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 265,
    "word": "contrary",
    "phonetic": "/contrary/",
    "definition": "adj. 相反的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "opposite",
      "conflicting"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"contrary\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 266,
    "word": "contrast",
    "phonetic": "/contrast/",
    "definition": "n. 对比",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "difference",
      "comparison"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"contrast\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 267,
    "word": "contribute",
    "phonetic": "/contribute/",
    "definition": "v. 贡献",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "donate",
      "provide"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"contribute\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 268,
    "word": "controversial",
    "phonetic": "/controversial/",
    "definition": "adj. 有争议的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"controversial\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 269,
    "word": "controversy",
    "phonetic": "/controversy/",
    "definition": "n. 争论",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"controversy\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 270,
    "word": "convenient",
    "phonetic": "/convenient/",
    "definition": "adj. 方便的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "handy",
      "suitable"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"convenient\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 271,
    "word": "convention",
    "phonetic": "/convention/",
    "definition": "n. 惯例",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"convention\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 272,
    "word": "conventional",
    "phonetic": "/conventional/",
    "definition": "adj. 传统的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "traditional",
      "usual"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"conventional\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 273,
    "word": "convert",
    "phonetic": "/convert/",
    "definition": "v. 转变",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "transform",
      "change"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"convert\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 274,
    "word": "convey",
    "phonetic": "/convey/",
    "definition": "v. 传达",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "communicate",
      "transport"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"convey\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 275,
    "word": "convict",
    "phonetic": "/convict/",
    "definition": "v. 定罪",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"convict\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 276,
    "word": "convince",
    "phonetic": "/convince/",
    "definition": "v. 使信服",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "persuade",
      "assure"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"convince\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 277,
    "word": "cooperate",
    "phonetic": "/cooperate/",
    "definition": "v. 合作",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "collaborate",
      "assist"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cooperate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 278,
    "word": "coordinate",
    "phonetic": "/coordinate/",
    "definition": "v. 协调",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"coordinate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 279,
    "word": "cope",
    "phonetic": "/cope/",
    "definition": "v. 处理",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "manage",
      "deal"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cope\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 280,
    "word": "core",
    "phonetic": "/core/",
    "definition": "n. 核心",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "center",
      "heart"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"core\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 281,
    "word": "corporate",
    "phonetic": "/corporate/",
    "definition": "adj. 公司的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "business",
      "company"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"corporate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 282,
    "word": "correspond",
    "phonetic": "/correspond/",
    "definition": "v. 符合",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"correspond\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 283,
    "word": "costly",
    "phonetic": "/costly/",
    "definition": "adj. 昂贵的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "expensive",
      "dear"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"costly\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 284,
    "word": "county",
    "phonetic": "/county/",
    "definition": "n. 郡",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"county\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 285,
    "word": "courage",
    "phonetic": "/courage/",
    "definition": "n. 勇气",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "bravery",
      "valor"
    ],
    "antonyms": [
      "cowardice"
    ],
    "example": "This is an example sentence using the word \"courage\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 286,
    "word": "course",
    "phonetic": "/course/",
    "definition": "n. 课程",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "class",
      "route"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"course\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 287,
    "word": "court",
    "phonetic": "/court/",
    "definition": "n. 法庭",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "tribunal",
      "woo"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"court\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 288,
    "word": "courtesy",
    "phonetic": "/courtesy/",
    "definition": "n. 礼貌",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"courtesy\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 289,
    "word": "cover",
    "phonetic": "/cover/",
    "definition": "v. 覆盖",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "hide",
      "protect"
    ],
    "antonyms": [
      "uncover"
    ],
    "example": "This is an example sentence using the word \"cover\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 290,
    "word": "crash",
    "phonetic": "/crash/",
    "definition": "v. 碰撞",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "collision",
      "collapse"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"crash\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 291,
    "word": "create",
    "phonetic": "/create/",
    "definition": "v. 创造",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "produce",
      "generate"
    ],
    "antonyms": [
      "destroy"
    ],
    "example": "This is an example sentence using the word \"create\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 292,
    "word": "creative",
    "phonetic": "/creative/",
    "definition": "adj. 创造性的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "imaginative",
      "original"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"creative\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 293,
    "word": "creature",
    "phonetic": "/creature/",
    "definition": "n. 生物",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"creature\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 294,
    "word": "credit",
    "phonetic": "/credit/",
    "definition": "n. 信用",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "praise",
      "trust"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"credit\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 295,
    "word": "creep",
    "phonetic": "/creep/",
    "definition": "v. 爬行",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"creep\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 296,
    "word": "crime",
    "phonetic": "/crime/",
    "definition": "n. 犯罪",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "offense",
      "wrongdoing"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"crime\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 297,
    "word": "crisis",
    "phonetic": "/crisis/",
    "definition": "n. 危机",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "emergency",
      "critical"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"crisis\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 298,
    "word": "criterion",
    "phonetic": "/criterion/",
    "definition": "n. 标准",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"criterion\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 299,
    "word": "critical",
    "phonetic": "/critical/",
    "definition": "adj. 批评的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "crucial",
      "disapproving"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"critical\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 300,
    "word": "criticism",
    "phonetic": "/criticism/",
    "definition": "n. 批评",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "blame",
      "critique"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"criticism\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 301,
    "word": "criticize",
    "phonetic": "/criticize/",
    "definition": "v. 批评",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "blame",
      "judge"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"criticize\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 302,
    "word": "crucial",
    "phonetic": "/crucial/",
    "definition": "adj. 关键的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "critical",
      "essential"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"crucial\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 303,
    "word": "crude",
    "phonetic": "/crude/",
    "definition": "adj. 粗糙的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"crude\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 304,
    "word": "cruel",
    "phonetic": "/cruel/",
    "definition": "adj. 残忍的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "brutal",
      "harsh"
    ],
    "antonyms": [
      "kind"
    ],
    "example": "This is an example sentence using the word \"cruel\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 305,
    "word": "crush",
    "phonetic": "/crush/",
    "definition": "v. 压碎",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "squash",
      "defeat"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"crush\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 306,
    "word": "cue",
    "phonetic": "/cue/",
    "definition": "n. 提示",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cue\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 307,
    "word": "cultivate",
    "phonetic": "/cultivate/",
    "definition": "v. 培养",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "develop",
      "nurture"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cultivate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 308,
    "word": "curious",
    "phonetic": "/curious/",
    "definition": "adj. 好奇的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "inquisitive",
      "odd"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"curious\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 309,
    "word": "current",
    "phonetic": "/current/",
    "definition": "adj. 当前的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "present",
      "flowing"
    ],
    "antonyms": [
      "past"
    ],
    "example": "This is an example sentence using the word \"current\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 310,
    "word": "curse",
    "phonetic": "/curse/",
    "definition": "n. 诅咒",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"curse\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 311,
    "word": "curve",
    "phonetic": "/curve/",
    "definition": "n. 曲线",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"curve\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 312,
    "word": "custom",
    "phonetic": "/custom/",
    "definition": "n. 习俗",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "tradition",
      "habit"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"custom\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 313,
    "word": "cycle",
    "phonetic": "/cycle/",
    "definition": "n. 循环",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"cycle\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 314,
    "word": "damage",
    "phonetic": "/damage/",
    "definition": "n. 损害",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "harm",
      "injury"
    ],
    "antonyms": [
      "repair"
    ],
    "example": "This is an example sentence using the word \"damage\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 315,
    "word": "dash",
    "phonetic": "/dash/",
    "definition": "v. 猛冲",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dash\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 316,
    "word": "data",
    "phonetic": "/data/",
    "definition": "n. 数据",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"data\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 317,
    "word": "dawn",
    "phonetic": "/dawn/",
    "definition": "n. 黎明",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "dusk"
    ],
    "example": "This is an example sentence using the word \"dawn\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 318,
    "word": "debate",
    "phonetic": "/debate/",
    "definition": "n. 辩论",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "discussion",
      "argue"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"debate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 319,
    "word": "decade",
    "phonetic": "/decade/",
    "definition": "n. 十年",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "ten years"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"decade\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 320,
    "word": "decay",
    "phonetic": "/decay/",
    "definition": "v. 腐烂",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "rot",
      "deteriorate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"decay\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 321,
    "word": "deceive",
    "phonetic": "/deceive/",
    "definition": "v. 欺骗",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "trick",
      "mislead"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"deceive\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 322,
    "word": "decent",
    "phonetic": "/decent/",
    "definition": "adj. 体面的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "proper",
      "respectable"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"decent\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 323,
    "word": "decide",
    "phonetic": "/decide/",
    "definition": "v. 决定",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "determine",
      "resolve"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"decide\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 324,
    "word": "decision",
    "phonetic": "/decision/",
    "definition": "n. 决定",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"decision\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 325,
    "word": "declare",
    "phonetic": "/declare/",
    "definition": "v. 宣布",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "announce",
      "state"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"declare\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 326,
    "word": "decline",
    "phonetic": "/decline/",
    "definition": "v. 下降",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "decrease",
      "refuse"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"decline\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 327,
    "word": "decorate",
    "phonetic": "/decorate/",
    "definition": "v. 装饰",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "adorn",
      "embellish"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"decorate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 328,
    "word": "decrease",
    "phonetic": "/decrease/",
    "definition": "v. 减少",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "reduce",
      "lessen"
    ],
    "antonyms": [
      "increase"
    ],
    "example": "This is an example sentence using the word \"decrease\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 329,
    "word": "dedicate",
    "phonetic": "/dedicate/",
    "definition": "v. 奉献",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dedicate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 330,
    "word": "deem",
    "phonetic": "/deem/",
    "definition": "v. 认为",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"deem\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 331,
    "word": "defeat",
    "phonetic": "/defeat/",
    "definition": "v. 击败",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "beat",
      "conquer"
    ],
    "antonyms": [
      "victory"
    ],
    "example": "This is an example sentence using the word \"defeat\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 332,
    "word": "defect",
    "phonetic": "/defect/",
    "definition": "n. 缺陷",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"defect\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 333,
    "word": "defend",
    "phonetic": "/defend/",
    "definition": "v. 保卫",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "protect",
      "guard"
    ],
    "antonyms": [
      "attack"
    ],
    "example": "This is an example sentence using the word \"defend\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 334,
    "word": "define",
    "phonetic": "/define/",
    "definition": "v. 定义",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "explain",
      "specify"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"define\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 335,
    "word": "definite",
    "phonetic": "/definite/",
    "definition": "adj. 明确的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "clear",
      "certain"
    ],
    "antonyms": [
      "indefinite"
    ],
    "example": "This is an example sentence using the word \"definite\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 336,
    "word": "delay",
    "phonetic": "/delay/",
    "definition": "v. 延迟",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "postpone",
      "defer"
    ],
    "antonyms": [
      "hurry"
    ],
    "example": "This is an example sentence using the word \"delay\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 337,
    "word": "delegate",
    "phonetic": "/delegate/",
    "definition": "n. 代表",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"delegate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 338,
    "word": "deliberate",
    "phonetic": "/deliberate/",
    "definition": "adj. 故意的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "intentional",
      "careful"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"deliberate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 339,
    "word": "delicate",
    "phonetic": "/delicate/",
    "definition": "adj. 精致的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "fragile",
      "fine"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"delicate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 340,
    "word": "delight",
    "phonetic": "/delight/",
    "definition": "n. 高兴",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "joy",
      "pleasure"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"delight\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 341,
    "word": "deliver",
    "phonetic": "/deliver/",
    "definition": "v. 递送",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "bring",
      "convey"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"deliver\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 342,
    "word": "demand",
    "phonetic": "/demand/",
    "definition": "v. 要求",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "require",
      "claim"
    ],
    "antonyms": [
      "supply"
    ],
    "example": "This is an example sentence using the word \"demand\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 343,
    "word": "democracy",
    "phonetic": "/democracy/",
    "definition": "n. 民主",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"democracy\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 344,
    "word": "demonstrate",
    "phonetic": "/demonstrate/",
    "definition": "v. 证明",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "show",
      "prove"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"demonstrate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 345,
    "word": "dense",
    "phonetic": "/dense/",
    "definition": "adj. 密集的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "thick",
      "compact"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dense\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 346,
    "word": "deny",
    "phonetic": "/deny/",
    "definition": "v. 否认",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "refuse",
      "reject"
    ],
    "antonyms": [
      "admit"
    ],
    "example": "This is an example sentence using the word \"deny\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 347,
    "word": "depart",
    "phonetic": "/depart/",
    "definition": "v. 离开",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "leave",
      "go"
    ],
    "antonyms": [
      "arrive"
    ],
    "example": "This is an example sentence using the word \"depart\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 348,
    "word": "dependent",
    "phonetic": "/dependent/",
    "definition": "adj. 依赖的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "reliant",
      "conditional"
    ],
    "antonyms": [
      "independent"
    ],
    "example": "This is an example sentence using the word \"dependent\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 349,
    "word": "depict",
    "phonetic": "/depict/",
    "definition": "v. 描绘",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "describe",
      "portray"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"depict\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 350,
    "word": "deposit",
    "phonetic": "/deposit/",
    "definition": "v. 存放",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "place",
      "put"
    ],
    "antonyms": [
      "withdraw"
    ],
    "example": "This is an example sentence using the word \"deposit\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 351,
    "word": "depress",
    "phonetic": "/depress/",
    "definition": "v. 使沮丧",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "sadden",
      "discourage"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"depress\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 352,
    "word": "deprive",
    "phonetic": "/deprive/",
    "definition": "v. 剥夺",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"deprive\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 353,
    "word": "derive",
    "phonetic": "/derive/",
    "definition": "v. 获得",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "obtain",
      "get"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"derive\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 354,
    "word": "descend",
    "phonetic": "/descend/",
    "definition": "v. 下降",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"descend\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 355,
    "word": "describe",
    "phonetic": "/describe/",
    "definition": "v. 描述",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "depict",
      "explain"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"describe\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 356,
    "word": "deserve",
    "phonetic": "/deserve/",
    "definition": "v. 值得",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "merit",
      "earn"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"deserve\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 357,
    "word": "design",
    "phonetic": "/design/",
    "definition": "v. 设计",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "plan",
      "intend"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"design\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 358,
    "word": "desirable",
    "phonetic": "/desirable/",
    "definition": "adj. 理想的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"desirable\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 359,
    "word": "desperate",
    "phonetic": "/desperate/",
    "definition": "adj. 绝望的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "hopeless",
      "despairing"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"desperate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 360,
    "word": "despite",
    "phonetic": "/despite/",
    "definition": "prep. 尽管",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "in spite of"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"despite\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 361,
    "word": "destination",
    "phonetic": "/destination/",
    "definition": "n. 目的地",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"destination\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 362,
    "word": "destroy",
    "phonetic": "/destroy/",
    "definition": "v. 破坏",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "ruin",
      "demolish"
    ],
    "antonyms": [
      "create"
    ],
    "example": "This is an example sentence using the word \"destroy\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 363,
    "word": "destruction",
    "phonetic": "/destruction/",
    "definition": "n. 破坏",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"destruction\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 364,
    "word": "detail",
    "phonetic": "/detail/",
    "definition": "n. 细节",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"detail\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 365,
    "word": "detect",
    "phonetic": "/detect/",
    "definition": "v. 察觉",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "discover",
      "find"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"detect\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 366,
    "word": "determine",
    "phonetic": "/determine/",
    "definition": "v. 决定",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "decide",
      "resolve"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"determine\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 367,
    "word": "develop",
    "phonetic": "/develop/",
    "definition": "v. 发展",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "grow",
      "evolve"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"develop\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 368,
    "word": "device",
    "phonetic": "/device/",
    "definition": "n. 装置",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"device\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 369,
    "word": "devise",
    "phonetic": "/devise/",
    "definition": "v. 设计",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"devise\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 370,
    "word": "devote",
    "phonetic": "/devote/",
    "definition": "v. 致力于",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "dedicate",
      "commit"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"devote\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 371,
    "word": "diagnose",
    "phonetic": "/diagnose/",
    "definition": "v. 诊断",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"diagnose\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 372,
    "word": "dictate",
    "phonetic": "/dictate/",
    "definition": "v. 口述",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dictate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 373,
    "word": "differ",
    "phonetic": "/differ/",
    "definition": "v. 不同",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "vary",
      "disagree"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"differ\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 374,
    "word": "difficult",
    "phonetic": "/difficult/",
    "definition": "adj. 困难的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "hard",
      "challenging"
    ],
    "antonyms": [
      "easy"
    ],
    "example": "This is an example sentence using the word \"difficult\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 375,
    "word": "digest",
    "phonetic": "/digest/",
    "definition": "v. 消化",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"digest\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 376,
    "word": "digital",
    "phonetic": "/digital/",
    "definition": "adj. 数字的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "electronic",
      "numeric"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"digital\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 377,
    "word": "dignity",
    "phonetic": "/dignity/",
    "definition": "n. 尊严",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "honor",
      "respect"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dignity\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 378,
    "word": "dilemma",
    "phonetic": "/dilemma/",
    "definition": "n. 困境",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "predicament",
      "problem"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dilemma\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 379,
    "word": "dimension",
    "phonetic": "/dimension/",
    "definition": "n. 维度",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dimension\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 380,
    "word": "diminish",
    "phonetic": "/diminish/",
    "definition": "v. 减少",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "decrease",
      "reduce"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"diminish\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 381,
    "word": "dine",
    "phonetic": "/dine/",
    "definition": "v. 进餐",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dine\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 382,
    "word": "dip",
    "phonetic": "/dip/",
    "definition": "v. 浸",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dip\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 383,
    "word": "diplomatic",
    "phonetic": "/diplomatic/",
    "definition": "adj. 外交的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"diplomatic\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 384,
    "word": "direct",
    "phonetic": "/direct/",
    "definition": "adj. 直接的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "straight",
      "guide"
    ],
    "antonyms": [
      "indirect"
    ],
    "example": "This is an example sentence using the word \"direct\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 385,
    "word": "disable",
    "phonetic": "/disable/",
    "definition": "v. 使残废",
    "rootDerivatives": "【前缀】dis=否定 → disable",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disable\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 386,
    "word": "disadvantage",
    "phonetic": "/disadvantage/",
    "definition": "n. 劣势",
    "rootDerivatives": "【前缀】dis=否定 → disadvantage",
    "synonyms": [
      "drawback",
      "weakness"
    ],
    "antonyms": [
      "advantage"
    ],
    "example": "This is an example sentence using the word \"disadvantage\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 387,
    "word": "disagree",
    "phonetic": "/disagree/",
    "definition": "v. 不同意",
    "rootDerivatives": "【前缀】dis=否定 → disagree",
    "synonyms": [
      "differ",
      "object"
    ],
    "antonyms": [
      "agree"
    ],
    "example": "This is an example sentence using the word \"disagree\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 388,
    "word": "disappear",
    "phonetic": "/disappear/",
    "definition": "v. 消失",
    "rootDerivatives": "【前缀】dis=否定 → disappear",
    "synonyms": [
      "vanish",
      "fade"
    ],
    "antonyms": [
      "appear"
    ],
    "example": "This is an example sentence using the word \"disappear\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 389,
    "word": "disappoint",
    "phonetic": "/disappoint/",
    "definition": "v. 使失望",
    "rootDerivatives": "【前缀】dis=否定 → disappoint",
    "synonyms": [
      "frustrate",
      "let down"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disappoint\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 390,
    "word": "disaster",
    "phonetic": "/disaster/",
    "definition": "n. 灾难",
    "rootDerivatives": "【前缀】dis=否定 → disaster",
    "synonyms": [
      "catastrophe",
      "tragedy"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disaster\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 391,
    "word": "discard",
    "phonetic": "/discard/",
    "definition": "v. 丢弃",
    "rootDerivatives": "【前缀】dis=否定 → discard",
    "synonyms": [
      "abandon",
      "throw away"
    ],
    "antonyms": [
      "keep"
    ],
    "example": "This is an example sentence using the word \"discard\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 392,
    "word": "discipline",
    "phonetic": "/discipline/",
    "definition": "n. 纪律",
    "rootDerivatives": "【前缀】dis=否定 → discipline",
    "synonyms": [
      "training",
      "punishment"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"discipline\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 393,
    "word": "disclose",
    "phonetic": "/disclose/",
    "definition": "v. 揭露",
    "rootDerivatives": "【前缀】dis=否定 → disclose",
    "synonyms": [
      "reveal",
      "expose"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disclose\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 394,
    "word": "discount",
    "phonetic": "/discount/",
    "definition": "n. 折扣",
    "rootDerivatives": "【前缀】dis=否定 → discount",
    "synonyms": [
      "reduction",
      "deduction"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"discount\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 395,
    "word": "discourage",
    "phonetic": "/discourage/",
    "definition": "v. 使气馁",
    "rootDerivatives": "【前缀】dis=否定 → discourage",
    "synonyms": [
      "deter",
      "dishearten"
    ],
    "antonyms": [
      "encourage"
    ],
    "example": "This is an example sentence using the word \"discourage\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 396,
    "word": "discover",
    "phonetic": "/discover/",
    "definition": "v. 发现",
    "rootDerivatives": "【前缀】dis=否定 → discover",
    "synonyms": [
      "find",
      "detect"
    ],
    "antonyms": [
      "conceal"
    ],
    "example": "This is an example sentence using the word \"discover\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 397,
    "word": "discreet",
    "phonetic": "/discreet/",
    "definition": "adj. 谨慎的",
    "rootDerivatives": "【前缀】dis=否定 → discreet",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"discreet\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 398,
    "word": "discriminate",
    "phonetic": "/discriminate/",
    "definition": "v. 歧视",
    "rootDerivatives": "【前缀】dis=否定 → discriminate",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"discriminate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 399,
    "word": "discuss",
    "phonetic": "/discuss/",
    "definition": "v. 讨论",
    "rootDerivatives": "【前缀】dis=否定 → discuss",
    "synonyms": [
      "debate",
      "talk over"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"discuss\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 400,
    "word": "disease",
    "phonetic": "/disease/",
    "definition": "n. 疾病",
    "rootDerivatives": "【前缀】dis=否定 → disease",
    "synonyms": [
      "illness",
      "sickness"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disease\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 401,
    "word": "disguise",
    "phonetic": "/disguise/",
    "definition": "v. 伪装",
    "rootDerivatives": "【前缀】dis=否定 → disguise",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disguise\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 402,
    "word": "disgust",
    "phonetic": "/disgust/",
    "definition": "n. 厌恶",
    "rootDerivatives": "【前缀】dis=否定 → disgust",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disgust\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 403,
    "word": "dismiss",
    "phonetic": "/dismiss/",
    "definition": "v. 解雇",
    "rootDerivatives": "【前缀】dis=否定 → dismiss",
    "synonyms": [
      "fire",
      "discharge"
    ],
    "antonyms": [
      "employ"
    ],
    "example": "This is an example sentence using the word \"dismiss\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 404,
    "word": "disorder",
    "phonetic": "/disorder/",
    "definition": "n. 混乱",
    "rootDerivatives": "【前缀】dis=否定 → disorder",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "order"
    ],
    "example": "This is an example sentence using the word \"disorder\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 405,
    "word": "display",
    "phonetic": "/display/",
    "definition": "v. 展示",
    "rootDerivatives": "【前缀】dis=否定 → display",
    "synonyms": [
      "show",
      "exhibit"
    ],
    "antonyms": [
      "hide"
    ],
    "example": "This is an example sentence using the word \"display\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 406,
    "word": "dispose",
    "phonetic": "/dispose/",
    "definition": "v. 处理",
    "rootDerivatives": "【前缀】dis=否定 → dispose",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dispose\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 407,
    "word": "dispute",
    "phonetic": "/dispute/",
    "definition": "n. 争论",
    "rootDerivatives": "【前缀】dis=否定 → dispute",
    "synonyms": [
      "debate",
      "argue"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dispute\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 408,
    "word": "disrupt",
    "phonetic": "/disrupt/",
    "definition": "v. 扰乱",
    "rootDerivatives": "【前缀】dis=否定 → disrupt",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disrupt\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 409,
    "word": "dissolve",
    "phonetic": "/dissolve/",
    "definition": "v. 溶解",
    "rootDerivatives": "【前缀】dis=否定 → dissolve",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dissolve\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 410,
    "word": "distinct",
    "phonetic": "/distinct/",
    "definition": "adj. 明显的",
    "rootDerivatives": "【前缀】dis=否定 → distinct",
    "synonyms": [
      "clear",
      "different"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"distinct\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 411,
    "word": "distinguish",
    "phonetic": "/distinguish/",
    "definition": "v. 区分",
    "rootDerivatives": "【前缀】dis=否定 → distinguish",
    "synonyms": [
      "differentiate",
      "tell apart"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"distinguish\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 412,
    "word": "distress",
    "phonetic": "/distress/",
    "definition": "n. 痛苦",
    "rootDerivatives": "【前缀】dis=否定 → distress",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"distress\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 413,
    "word": "distribute",
    "phonetic": "/distribute/",
    "definition": "v. 分配",
    "rootDerivatives": "【前缀】dis=否定 → distribute",
    "synonyms": [
      "dispense",
      "hand out"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"distribute\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 414,
    "word": "disturb",
    "phonetic": "/disturb/",
    "definition": "v. 打扰",
    "rootDerivatives": "【前缀】dis=否定 → disturb",
    "synonyms": [
      "bother",
      "interrupt"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"disturb\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 415,
    "word": "diverse",
    "phonetic": "/diverse/",
    "definition": "adj. 多样的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "various",
      "different"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"diverse\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 416,
    "word": "divide",
    "phonetic": "/divide/",
    "definition": "v. 分开",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "separate",
      "split"
    ],
    "antonyms": [
      "unite"
    ],
    "example": "This is an example sentence using the word \"divide\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 417,
    "word": "divorce",
    "phonetic": "/divorce/",
    "definition": "n. 离婚",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "marry"
    ],
    "example": "This is an example sentence using the word \"divorce\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 418,
    "word": "document",
    "phonetic": "/document/",
    "definition": "n. 文件",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "record",
      "paper"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"document\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 419,
    "word": "domestic",
    "phonetic": "/domestic/",
    "definition": "adj. 国内的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "home",
      "household"
    ],
    "antonyms": [
      "foreign"
    ],
    "example": "This is an example sentence using the word \"domestic\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 420,
    "word": "dominant",
    "phonetic": "/dominant/",
    "definition": "adj. 占优势的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "leading",
      "main"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dominant\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 421,
    "word": "dominate",
    "phonetic": "/dominate/",
    "definition": "v. 支配",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dominate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 422,
    "word": "donate",
    "phonetic": "/donate/",
    "definition": "v. 捐赠",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "contribute",
      "give"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"donate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 423,
    "word": "doom",
    "phonetic": "/doom/",
    "definition": "n. 厄运",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"doom\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 424,
    "word": "dose",
    "phonetic": "/dose/",
    "definition": "n. 剂量",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dose\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 425,
    "word": "draft",
    "phonetic": "/draft/",
    "definition": "n. 草稿",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "outline",
      "sketch"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"draft\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 426,
    "word": "drag",
    "phonetic": "/drag/",
    "definition": "v. 拖",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "pull",
      "haul"
    ],
    "antonyms": [
      "push"
    ],
    "example": "This is an example sentence using the word \"drag\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 427,
    "word": "drain",
    "phonetic": "/drain/",
    "definition": "v. 排水",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"drain\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 428,
    "word": "dramatic",
    "phonetic": "/dramatic/",
    "definition": "adj. 戏剧性的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "striking",
      "impressive"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dramatic\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 429,
    "word": "draw",
    "phonetic": "/draw/",
    "definition": "v. 画，拉",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "sketch",
      "pull"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"draw\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 430,
    "word": "drift",
    "phonetic": "/drift/",
    "definition": "v. 漂流",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"drift\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 431,
    "word": "drip",
    "phonetic": "/drip/",
    "definition": "v. 滴下",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"drip\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 432,
    "word": "drop",
    "phonetic": "/drop/",
    "definition": "v. 落下",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "fall",
      "decline"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"drop\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 433,
    "word": "drown",
    "phonetic": "/drown/",
    "definition": "v. 淹死",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"drown\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 434,
    "word": "drug",
    "phonetic": "/drug/",
    "definition": "n. 药物",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "medicine",
      "medication"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"drug\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 435,
    "word": "due",
    "phonetic": "/due/",
    "definition": "adj. 到期的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "owing",
      "expected"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"due\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 436,
    "word": "dull",
    "phonetic": "/dull/",
    "definition": "adj. 枯燥的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "boring",
      "blunt"
    ],
    "antonyms": [
      "sharp"
    ],
    "example": "This is an example sentence using the word \"dull\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 437,
    "word": "dump",
    "phonetic": "/dump/",
    "definition": "v. 倾倒",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dump\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 438,
    "word": "duration",
    "phonetic": "/duration/",
    "definition": "n. 持续",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"duration\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 439,
    "word": "during",
    "phonetic": "/during/",
    "definition": "prep. 在...期间",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "throughout",
      "in"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"during\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 440,
    "word": "duty",
    "phonetic": "/duty/",
    "definition": "n. 职责",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "responsibility",
      "obligation"
    ],
    "antonyms": [
      "privilege"
    ],
    "example": "This is an example sentence using the word \"duty\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 441,
    "word": "dwell",
    "phonetic": "/dwell/",
    "definition": "v. 居住",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"dwell\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 442,
    "word": "dynamic",
    "phonetic": "/dynamic/",
    "definition": "adj. 动态的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "static"
    ],
    "example": "This is an example sentence using the word \"dynamic\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 443,
    "word": "eager",
    "phonetic": "/eager/",
    "definition": "adj. 渴望的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "keen",
      "enthusiastic"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"eager\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 444,
    "word": "earn",
    "phonetic": "/earn/",
    "definition": "v. 挣得",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "gain",
      "deserve"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"earn\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 445,
    "word": "ease",
    "phonetic": "/ease/",
    "definition": "n. 容易",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "comfort",
      "relief"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"ease\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 446,
    "word": "echo",
    "phonetic": "/echo/",
    "definition": "n. 回声",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"echo\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 447,
    "word": "economic",
    "phonetic": "/economic/",
    "definition": "adj. 经济的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "financial",
      "monetary"
    ],
    "antonyms": [
      "uneconomic"
    ],
    "example": "This is an example sentence using the word \"economic\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 448,
    "word": "economy",
    "phonetic": "/economy/",
    "definition": "n. 经济",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "thrift",
      "saving"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"economy\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 449,
    "word": "edge",
    "phonetic": "/edge/",
    "definition": "n. 边缘",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "border",
      "margin"
    ],
    "antonyms": [
      "center"
    ],
    "example": "This is an example sentence using the word \"edge\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 450,
    "word": "edit",
    "phonetic": "/edit/",
    "definition": "v. 编辑",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "revise",
      "correct"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"edit\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 451,
    "word": "educate",
    "phonetic": "/educate/",
    "definition": "v. 教育",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "teach",
      "instruct"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"educate\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 452,
    "word": "effect",
    "phonetic": "/effect/",
    "definition": "n. 影响",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "result",
      "impact"
    ],
    "antonyms": [
      "cause"
    ],
    "example": "This is an example sentence using the word \"effect\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 453,
    "word": "effective",
    "phonetic": "/effective/",
    "definition": "adj. 有效的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "efficient",
      "valid"
    ],
    "antonyms": [
      "ineffective"
    ],
    "example": "This is an example sentence using the word \"effective\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 454,
    "word": "efficient",
    "phonetic": "/efficient/",
    "definition": "adj. 高效的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "effective",
      "competent"
    ],
    "antonyms": [
      "inefficient"
    ],
    "example": "This is an example sentence using the word \"efficient\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 455,
    "word": "effort",
    "phonetic": "/effort/",
    "definition": "n. 努力",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "attempt",
      "endeavor"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"effort\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 456,
    "word": "elaborate",
    "phonetic": "/elaborate/",
    "definition": "adj. 详尽的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"elaborate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 457,
    "word": "elect",
    "phonetic": "/elect/",
    "definition": "v. 选举",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "choose",
      "select"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"elect\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 458,
    "word": "elegant",
    "phonetic": "/elegant/",
    "definition": "adj. 优雅的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "graceful",
      "refined"
    ],
    "antonyms": [
      "inelegant"
    ],
    "example": "This is an example sentence using the word \"elegant\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 459,
    "word": "element",
    "phonetic": "/element/",
    "definition": "n. 元素",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "component",
      "factor"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"element\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 460,
    "word": "elementary",
    "phonetic": "/elementary/",
    "definition": "adj. 基本的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"elementary\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 461,
    "word": "eliminate",
    "phonetic": "/eliminate/",
    "definition": "v. 消除",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "remove",
      "exclude"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"eliminate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 462,
    "word": "elite",
    "phonetic": "/elite/",
    "definition": "n. 精英",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"elite\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 463,
    "word": "embarrass",
    "phonetic": "/embarrass/",
    "definition": "v. 使尴尬",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "shame",
      "humiliate"
    ],
    "antonyms": [
      "comfort"
    ],
    "example": "This is an example sentence using the word \"embarrass\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 464,
    "word": "embassy",
    "phonetic": "/embassy/",
    "definition": "n. 大使馆",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"embassy\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 465,
    "word": "embrace",
    "phonetic": "/embrace/",
    "definition": "v. 拥抱",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "hug",
      "accept"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"embrace\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 466,
    "word": "emerge",
    "phonetic": "/emerge/",
    "definition": "v. 出现",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "appear",
      "arise"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"emerge\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 467,
    "word": "emergency",
    "phonetic": "/emergency/",
    "definition": "n. 紧急情况",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "crisis",
      "urgency"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"emergency\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 468,
    "word": "emit",
    "phonetic": "/emit/",
    "definition": "v. 发出",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"emit\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 469,
    "word": "emotion",
    "phonetic": "/emotion/",
    "definition": "n. 情感",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "feeling",
      "sentiment"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"emotion\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 470,
    "word": "emphasis",
    "phonetic": "/emphasis/",
    "definition": "n. 强调",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "stress",
      "importance"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"emphasis\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 471,
    "word": "empire",
    "phonetic": "/empire/",
    "definition": "n. 帝国",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"empire\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 472,
    "word": "employ",
    "phonetic": "/employ/",
    "definition": "v. 雇用",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "hire",
      "use"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"employ\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 473,
    "word": "empty",
    "phonetic": "/empty/",
    "definition": "adj. 空的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "vacant",
      "void"
    ],
    "antonyms": [
      "full"
    ],
    "example": "This is an example sentence using the word \"empty\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 474,
    "word": "enable",
    "phonetic": "/enable/",
    "definition": "v. 使能够",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "allow",
      "permit"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"enable\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 475,
    "word": "enclose",
    "phonetic": "/enclose/",
    "definition": "v. 围住",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"enclose\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 476,
    "word": "encounter",
    "phonetic": "/encounter/",
    "definition": "v. 遇到",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "meet",
      "face"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"encounter\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 477,
    "word": "encourage",
    "phonetic": "/encourage/",
    "definition": "v. 鼓励",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "inspire",
      "support"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"encourage\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 478,
    "word": "endure",
    "phonetic": "/endure/",
    "definition": "v. 忍受",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "bear",
      "tolerate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"endure\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 479,
    "word": "enemy",
    "phonetic": "/enemy/",
    "definition": "n. 敌人",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "friend"
    ],
    "example": "This is an example sentence using the word \"enemy\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 480,
    "word": "energy",
    "phonetic": "/energy/",
    "definition": "n. 能量",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "vigor",
      "power"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"energy\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 481,
    "word": "enforce",
    "phonetic": "/enforce/",
    "definition": "v. 执行",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "implement",
      "apply"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"enforce\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 482,
    "word": "engage",
    "phonetic": "/engage/",
    "definition": "v. 从事",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "involve",
      "occupy"
    ],
    "antonyms": [
      "disengage"
    ],
    "example": "This is an example sentence using the word \"engage\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 483,
    "word": "engine",
    "phonetic": "/engine/",
    "definition": "n. 引擎",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"engine\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 484,
    "word": "enhance",
    "phonetic": "/enhance/",
    "definition": "v. 提高",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "improve",
      "boost"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"enhance\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 485,
    "word": "enjoy",
    "phonetic": "/enjoy/",
    "definition": "v. 享受",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "like",
      "appreciate"
    ],
    "antonyms": [
      "suffer"
    ],
    "example": "This is an example sentence using the word \"enjoy\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 486,
    "word": "enormous",
    "phonetic": "/enormous/",
    "definition": "adj. 巨大的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "huge",
      "vast"
    ],
    "antonyms": [
      "tiny"
    ],
    "example": "This is an example sentence using the word \"enormous\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 487,
    "word": "ensure",
    "phonetic": "/ensure/",
    "definition": "v. 确保",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "guarantee",
      "make sure"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"ensure\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 488,
    "word": "enterprise",
    "phonetic": "/enterprise/",
    "definition": "n. 企业",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"enterprise\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 489,
    "word": "entertain",
    "phonetic": "/entertain/",
    "definition": "v. 娱乐",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "amuse",
      "host"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"entertain\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 490,
    "word": "enthusiasm",
    "phonetic": "/enthusiasm/",
    "definition": "n. 热情",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "passion",
      "zeal"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"enthusiasm\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 491,
    "word": "entire",
    "phonetic": "/entire/",
    "definition": "adj. 整个的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "whole",
      "complete"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"entire\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 492,
    "word": "entitle",
    "phonetic": "/entitle/",
    "definition": "v. 给予权利",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "authorize",
      "qualify"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"entitle\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 493,
    "word": "entrance",
    "phonetic": "/entrance/",
    "definition": "n. 入口",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "exit"
    ],
    "example": "This is an example sentence using the word \"entrance\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 494,
    "word": "entry",
    "phonetic": "/entry/",
    "definition": "n. 进入",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"entry\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 495,
    "word": "environment",
    "phonetic": "/environment/",
    "definition": "n. 环境",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "surroundings",
      "setting"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"environment\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 496,
    "word": "envy",
    "phonetic": "/envy/",
    "definition": "v. 羡慕",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"envy\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 497,
    "word": "episode",
    "phonetic": "/episode/",
    "definition": "n. 插曲",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"episode\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 498,
    "word": "equal",
    "phonetic": "/equal/",
    "definition": "adj. 相等的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "same",
      "equivalent"
    ],
    "antonyms": [
      "unequal"
    ],
    "example": "This is an example sentence using the word \"equal\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 499,
    "word": "equip",
    "phonetic": "/equip/",
    "definition": "v. 装备",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "furnish",
      "provide"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"equip\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 500,
    "word": "equivalent",
    "phonetic": "/equivalent/",
    "definition": "adj. 等价的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"equivalent\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 501,
    "word": "era",
    "phonetic": "/era/",
    "definition": "n. 时代",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"era\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 502,
    "word": "erect",
    "phonetic": "/erect/",
    "definition": "v. 建立",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"erect\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 503,
    "word": "error",
    "phonetic": "/error/",
    "definition": "n. 错误",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "mistake",
      "fault"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"error\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 504,
    "word": "escape",
    "phonetic": "/escape/",
    "definition": "v. 逃跑",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "flee",
      "get away"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"escape\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 505,
    "word": "especially",
    "phonetic": "/especially/",
    "definition": "adv. 尤其",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"especially\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 506,
    "word": "essay",
    "phonetic": "/essay/",
    "definition": "n. 文章",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"essay\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 507,
    "word": "essential",
    "phonetic": "/essential/",
    "definition": "adj. 必要的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "necessary",
      "vital"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"essential\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 508,
    "word": "establish",
    "phonetic": "/establish/",
    "definition": "v. 建立",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "found",
      "set up"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"establish\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 509,
    "word": "estate",
    "phonetic": "/estate/",
    "definition": "n. 地产",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"estate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 510,
    "word": "estimate",
    "phonetic": "/estimate/",
    "definition": "v. 估计",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "assess",
      "evaluate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"estimate\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 511,
    "word": "evaluate",
    "phonetic": "/evaluate/",
    "definition": "v. 评估",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "assess",
      "judge"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"evaluate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 512,
    "word": "evaporate",
    "phonetic": "/evaporate/",
    "definition": "v. 蒸发",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"evaporate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 513,
    "word": "event",
    "phonetic": "/event/",
    "definition": "n. 事件",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "incident",
      "occurrence"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"event\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 514,
    "word": "eventually",
    "phonetic": "/eventually/",
    "definition": "adv. 最终",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "finally",
      "ultimately"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"eventually\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 515,
    "word": "evidence",
    "phonetic": "/evidence/",
    "definition": "n. 证据",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "proof",
      "sign"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"evidence\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 516,
    "word": "evil",
    "phonetic": "/evil/",
    "definition": "adj. 邪恶的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "wicked",
      "bad"
    ],
    "antonyms": [
      "good"
    ],
    "example": "This is an example sentence using the word \"evil\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 517,
    "word": "evolve",
    "phonetic": "/evolve/",
    "definition": "v. 进化",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"evolve\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 518,
    "word": "exact",
    "phonetic": "/exact/",
    "definition": "adj. 精确的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "precise",
      "accurate"
    ],
    "antonyms": [
      "inexact"
    ],
    "example": "This is an example sentence using the word \"exact\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 519,
    "word": "exaggerate",
    "phonetic": "/exaggerate/",
    "definition": "v. 夸大",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"exaggerate\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 520,
    "word": "examine",
    "phonetic": "/examine/",
    "definition": "v. 检查",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "inspect",
      "check"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"examine\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 521,
    "word": "example",
    "phonetic": "/example/",
    "definition": "n. 例子",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "instance",
      "sample"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"example\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 522,
    "word": "exceed",
    "phonetic": "/exceed/",
    "definition": "v. 超过",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"exceed\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 523,
    "word": "excellent",
    "phonetic": "/excellent/",
    "definition": "adj. 优秀的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "outstanding",
      "superb"
    ],
    "antonyms": [
      "terrible"
    ],
    "example": "This is an example sentence using the word \"excellent\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 524,
    "word": "except",
    "phonetic": "/except/",
    "definition": "prep. 除...外",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "besides",
      "apart from"
    ],
    "antonyms": [
      "include"
    ],
    "example": "This is an example sentence using the word \"except\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 525,
    "word": "exception",
    "phonetic": "/exception/",
    "definition": "n. 例外",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"exception\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 526,
    "word": "excess",
    "phonetic": "/excess/",
    "definition": "n. 过量",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "lack"
    ],
    "example": "This is an example sentence using the word \"excess\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 527,
    "word": "exchange",
    "phonetic": "/exchange/",
    "definition": "v. 交换",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "swap",
      "trade"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"exchange\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 528,
    "word": "excite",
    "phonetic": "/excite/",
    "definition": "v. 使兴奋",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "thrill",
      "stimulate"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"excite\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 529,
    "word": "exclude",
    "phonetic": "/exclude/",
    "definition": "v. 排除",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "include"
    ],
    "example": "This is an example sentence using the word \"exclude\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 530,
    "word": "excuse",
    "phonetic": "/excuse/",
    "definition": "n. 借口",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "pardon",
      "reason"
    ],
    "antonyms": [
      "blame"
    ],
    "example": "This is an example sentence using the word \"excuse\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 531,
    "word": "execute",
    "phonetic": "/execute/",
    "definition": "v. 执行",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"execute\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 532,
    "word": "exercise",
    "phonetic": "/exercise/",
    "definition": "n. 锻炼",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "practice",
      "work out"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"exercise\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 533,
    "word": "exhaust",
    "phonetic": "/exhaust/",
    "definition": "v. 耗尽",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "tire",
      "drain"
    ],
    "antonyms": [
      "refresh"
    ],
    "example": "This is an example sentence using the word \"exhaust\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 534,
    "word": "exhibit",
    "phonetic": "/exhibit/",
    "definition": "v. 展览",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"exhibit\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 535,
    "word": "exist",
    "phonetic": "/exist/",
    "definition": "v. 存在",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "live",
      "be"
    ],
    "antonyms": [
      "vanish"
    ],
    "example": "This is an example sentence using the word \"exist\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 536,
    "word": "exit",
    "phonetic": "/exit/",
    "definition": "n. 出口",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "entrance"
    ],
    "example": "This is an example sentence using the word \"exit\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 537,
    "word": "expand",
    "phonetic": "/expand/",
    "definition": "v. 扩大",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "enlarge",
      "grow"
    ],
    "antonyms": [
      "contract"
    ],
    "example": "This is an example sentence using the word \"expand\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 538,
    "word": "expansion",
    "phonetic": "/expansion/",
    "definition": "n. 扩张",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"expansion\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 539,
    "word": "expect",
    "phonetic": "/expect/",
    "definition": "v. 期望",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "anticipate",
      "hope"
    ],
    "antonyms": [
      "doubt"
    ],
    "example": "This is an example sentence using the word \"expect\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 540,
    "word": "expense",
    "phonetic": "/expense/",
    "definition": "n. 费用",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"expense\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 541,
    "word": "expensive",
    "phonetic": "/expensive/",
    "definition": "adj. 昂贵的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "costly",
      "dear"
    ],
    "antonyms": [
      "cheap"
    ],
    "example": "This is an example sentence using the word \"expensive\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 542,
    "word": "experience",
    "phonetic": "/experience/",
    "definition": "n. 经验",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "undergo",
      "knowledge"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"experience\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 543,
    "word": "experiment",
    "phonetic": "/experiment/",
    "definition": "n. 实验",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"experiment\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 544,
    "word": "expert",
    "phonetic": "/expert/",
    "definition": "n. 专家",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "specialist",
      "authority"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"expert\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 545,
    "word": "explain",
    "phonetic": "/explain/",
    "definition": "v. 解释",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "clarify",
      "account for"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"explain\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 546,
    "word": "explicit",
    "phonetic": "/explicit/",
    "definition": "adj. 明确的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"explicit\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 547,
    "word": "explode",
    "phonetic": "/explode/",
    "definition": "v. 爆炸",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "burst",
      "blow up"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"explode\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 548,
    "word": "exploit",
    "phonetic": "/exploit/",
    "definition": "v. 开发",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"exploit\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 549,
    "word": "explore",
    "phonetic": "/explore/",
    "definition": "v. 探索",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "investigate",
      "discover"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"explore\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 550,
    "word": "export",
    "phonetic": "/export/",
    "definition": "v. 出口",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "ship abroad"
    ],
    "antonyms": [
      "import"
    ],
    "example": "This is an example sentence using the word \"export\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 551,
    "word": "expose",
    "phonetic": "/expose/",
    "definition": "v. 暴露",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "reveal",
      "uncover"
    ],
    "antonyms": [
      "conceal"
    ],
    "example": "This is an example sentence using the word \"expose\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 552,
    "word": "express",
    "phonetic": "/express/",
    "definition": "v. 表达",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "convey",
      "voice"
    ],
    "antonyms": [
      "imply"
    ],
    "example": "This is an example sentence using the word \"express\".",
    "frequency": 5,
    "category": "高频核心"
  },
  {
    "id": 553,
    "word": "extend",
    "phonetic": "/extend/",
    "definition": "v. 延伸",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "stretch",
      "prolong"
    ],
    "antonyms": [
      "shorten"
    ],
    "example": "This is an example sentence using the word \"extend\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 554,
    "word": "extension",
    "phonetic": "/extension/",
    "definition": "n. 延伸",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"extension\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 555,
    "word": "extensive",
    "phonetic": "/extensive/",
    "definition": "adj. 广泛的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"extensive\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 556,
    "word": "extent",
    "phonetic": "/extent/",
    "definition": "n. 程度",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "degree",
      "scope"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"extent\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 557,
    "word": "external",
    "phonetic": "/external/",
    "definition": "adj. 外部的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "outer",
      "outside"
    ],
    "antonyms": [
      "internal"
    ],
    "example": "This is an example sentence using the word \"external\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 558,
    "word": "extinct",
    "phonetic": "/extinct/",
    "definition": "adj. 灭绝的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"extinct\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 559,
    "word": "extra",
    "phonetic": "/extra/",
    "definition": "adj. 额外的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "additional",
      "spare"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"extra\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 560,
    "word": "extract",
    "phonetic": "/extract/",
    "definition": "v. 提取",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"extract\".",
    "frequency": 3,
    "category": "学术词汇"
  },
  {
    "id": 561,
    "word": "extraordinary",
    "phonetic": "/extraordinary/",
    "definition": "adj. 非凡的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "opposite 1",
      "opposite 2"
    ],
    "example": "This is an example sentence using the word \"extraordinary\".",
    "frequency": 4,
    "category": "高频核心"
  },
  {
    "id": 562,
    "word": "extreme",
    "phonetic": "/extreme/",
    "definition": "adj. 极端的",
    "rootDerivatives": "【词根】分析词根构成，记忆相关衍生词",
    "synonyms": [
      "similar word 1",
      "similar word 2"
    ],
    "antonyms": [
      "moderate"
    ],
    "example": "This is an example sentence using the word \"extreme\".",
    "frequency": 4,
    "category": "高频核心"
  }
];

module.exports = vocabularyData;
