// 易错易混词汇分组数据
// 每组包含相似或易混淆的词汇，附带辨析说明

const confusableGroups = [
  {
    id: 1,
    title: "abandon vs desert vs forsake",
    description: "都表示'放弃'，但用法不同",
    words: [
      {
        word: "abandon",
        definition: "强调完全、永远地放弃，不再关心",
        example: "He abandoned his wife and children. (他抛弃妻儿。)",
        note: "语气最强，常指不负责任地抛弃"
      },
      {
        word: "desert",
        definition: "强调违背责任、义务而离开",
        example: "The soldier deserted his post. (士兵擅离职守。)",
        note: "常指军人逃跑、违背职责"
      },
      {
        word: "forsake",
        definition: "强调断绝情感联系，抛弃所爱",
        example: "She promised never to forsake him. (她承诺永不背弃他。)",
        note: "文学色彩浓，常指感情上的背弃"
      }
    ],
    distinction: "abandon强调彻底放弃；desert强调违背责任；forsake强调情感背弃"
  },
  {
    id: 2,
    title: "ability vs capability vs capacity",
    description: "都表示'能力'，但侧重点不同",
    words: [
      {
        word: "ability",
        definition: "做某事的能力，后天习得",
        example: "She has the ability to speak four languages. (她有能力说四种语言。)",
        note: "最常用，可指先天或后天能力"
      },
      {
        word: "capability",
        definition: "潜在的能力，尚未开发的才能",
        example: "The country has nuclear capabilities. (该国拥有核能力。)",
        note: "常指潜在、待开发的才能或性能"
      },
      {
        word: "capacity",
        definition: "容纳、吸收的能力，容量",
        example: "The stadium has a capacity of 50,000. (体育场可容纳5万人。)",
        note: "常指容纳量、容积或理解能力"
      }
    ],
    distinction: "ability侧重实际能力；capability侧重潜能；capacity侧重容量/理解力"
  },
  {
    id: 3,
    title: "accept vs receive",
    description: "都与'收到'相关，但含义不同",
    words: [
      {
        word: "accept",
        definition: "主观上接受、同意",
        example: "I accept your apology. (我接受你的道歉。)",
        note: "强调主观意愿，愿意接纳"
      },
      {
        word: "receive",
        definition: "客观上收到，不涉及主观态度",
        example: "I received a letter yesterday. (我昨天收到一封信。)",
        note: "仅表示客观收到，不涉及是否接受"
      }
    ],
    distinction: "receive是客观收到；accept是主观接受"
  },
  {
    id: 4,
    title: "accomplish vs achieve vs complete",
    description: "都表示'完成'，但语境不同",
    words: [
      {
        word: "accomplish",
        definition: "成功完成某项任务或目标",
        example: "We accomplished our mission. (我们完成了使命。)",
        note: "强调成功完成，有成就感"
      },
      {
        word: "achieve",
        definition: "通过努力达成目标，取得成就",
        example: "She achieved her goal of becoming a doctor. (她实现了成为医生的目标。)",
        note: "强调克服困难后取得"
      },
      {
        word: "complete",
        definition: "使完整，完成 unfinished 的工作",
        example: "The building was completed last year. (大楼去年竣工。)",
        note: "强调使某物完整、完工"
      }
    ],
    distinction: "accomplish强调成功；achieve强调努力后的成就；complete强调整体完工"
  },
  {
    id: 5,
    title: "accurate vs exact vs precise",
    description: "都表示'准确'，但精确度不同",
    words: [
      {
        word: "accurate",
        definition: "准确的，无误的，符合事实",
        example: "The report is accurate and reliable. (报告准确可靠。)",
        note: "强调符合事实，无错误"
      },
      {
        word: "exact",
        definition: "精确的，丝毫不差的",
        example: "What's the exact time? (确切时间是几点？)",
        note: "强调丝毫不差，完全吻合"
      },
      {
        word: "precise",
        definition: "精密的，精确的，细节准确",
        example: "The measurements need to be precise. (测量需要精确。)",
        note: "强调细节精确，常用于科技"
      }
    ],
    distinction: "accurate强调正确性；exact强调完全吻合；precise强调细节精确"
  },
  {
    id: 6,
    title: "admit vs confess vs acknowledge",
    description: "都表示'承认'，但语境和语气不同",
    words: [
      {
        word: "admit",
        definition: "承认事实或错误，不情愿地",
        example: "He admitted his mistake. (他承认了错误。)",
        note: "常指不情愿地承认"
      },
      {
        word: "confess",
        definition: "坦白，忏悔，承认罪行或过错",
        example: "The thief confessed to the crime. (小偷坦白了罪行。)",
        note: "常指承认罪行、过错或隐私"
      },
      {
        word: "acknowledge",
        definition: "公开承认，认可某事的存在",
        example: "He acknowledged defeat gracefully. (他大方地认输。)",
        note: "强调公开、正式地承认"
      }
    ],
    distinction: "admit指承认事实；confess指坦白罪行；acknowledge指公开认可"
  },
  {
    id: 7,
    title: "affect vs effect",
    description: "形近词，词性和含义都不同",
    words: [
      {
        word: "affect",
        definition: "v. 影响，感动，假装",
        example: "The weather affects my mood. (天气影响我的心情。)",
        note: "动词，强调对...产生影响"
      },
      {
        word: "effect",
        definition: "n. 影响，效果；v. 实现",
        example: "The medicine had a positive effect. (药物产生了积极效果。)",
        note: "名词表效果，动词表实现"
      }
    ],
    distinction: "affect是动词'影响'；effect是名词'效果'(动词表'实现')"
  },
  {
    id: 8,
    title: "alone vs lonely vs lone",
    description: "都与'单独'相关，但含义不同",
    words: [
      {
        word: "alone",
        definition: "adj./adv. 独自的/地，单独的",
        example: "She lives alone in the city. (她独自住在城里。)",
        note: "客观状态，不表情感"
      },
      {
        word: "lonely",
        definition: "adj. 孤独的，寂寞的",
        example: "I feel lonely when you're away. (你不在时我感到孤独。)",
        note: "主观感受，表情感上的孤独"
      },
      {
        word: "lone",
        definition: "adj. 单独的，唯一的",
        example: "A lone wolf howled in the distance. (一只孤狼在远处嚎叫。)",
        note: "常作定语，文学色彩浓"
      }
    ],
    distinction: "alone表客观独自；lonely表主观孤独；lone作定语表单独"
  },
  {
    id: 9,
    title: "amount vs number vs quantity",
    description: "都表示'数量'，但用法不同",
    words: [
      {
        word: "amount",
        definition: "数量，总额，修饰不可数名词",
        example: "A large amount of money was spent. (花了大量金钱。)",
        note: "与不可数名词连用"
      },
      {
        word: "number",
        definition: "数字，数目，修饰可数名词",
        example: "A number of students were absent. (许多学生缺席。)",
        note: "与可数名词复数连用"
      },
      {
        word: "quantity",
        definition: "数量，分量，可修饰可数/不可数",
        example: "Quality is more important than quantity. (质量比数量重要。)",
        note: "正式用语，常与of连用"
      }
    ],
    distinction: "amount+不可数名词；number+可数名词复数；quantity正式用语"
  },
  {
    id: 10,
    title: "arise vs rise vs raise",
    description: "形近词，含义和用法都不同",
    words: [
      {
        word: "arise",
        definition: "vi. 出现，产生，起身",
        example: "Problems arose during the project. (项目进行中出现了很多问题。)",
        note: "不及物，常指问题产生"
      },
      {
        word: "rise",
        definition: "vi. 上升，升起，上涨",
        example: "The sun rises in the east. (太阳从东方升起。)",
        note: "不及物，自然上升"
      },
      {
        word: "raise",
        definition: "vt. 举起，提高，养育",
        example: "Please raise your hand. (请举手。)",
        note: "及物动词，需接宾语"
      }
    ],
    distinction: "arise不及物表'产生'；rise不及物表'上升'；raise及物表'举起'"
  }
];

module.exports = confusableGroups;
