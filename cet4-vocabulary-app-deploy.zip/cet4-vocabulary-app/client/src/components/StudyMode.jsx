import React, { useState, useEffect, useCallback } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RotateCcw, Shuffle, Trophy, AlertCircle } from 'lucide-react';
import WordCard from './WordCard';
import { studyAPI } from '../utils/api';
import { getProgressMessage } from '../utils/helpers';

const StudyMode = () => {
  const [queue, setQueue] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [progress, setProgress] = useState(null);
  const [shuffle, setShuffle] = useState(false);
  const [showComplete, setShowComplete] = useState(false);
  const [passedWords, setPassedWords] = useState(new Set());
  
  // 加载学习队列
  const loadQueue = useCallback(async (shouldShuffle = false) => {
    try {
      setLoading(true);
      setError(null);
      
      const response = await studyAPI.getQueue(shouldShuffle);
      
      if (response.success) {
        setQueue(response.data);
        setProgress(response.progress);
        setCurrentIndex(0);
        setPassedWords(new Set());
        
        if (response.data.length === 0) {
          setShowComplete(true);
        } else {
          setShowComplete(false);
        }
      } else {
        setError('加载失败，请重试');
      }
    } catch (err) {
      setError('网络错误，请检查连接');
    } finally {
      setLoading(false);
    }
  }, []);
  
  // 初始加载
  useEffect(() => {
    loadQueue();
  }, [loadQueue]);
  
  // 标记熟词（斩）- 完全掌握，从队列移除
  const handleMaster = async (wordId) => {
    try {
      const response = await studyAPI.markMastered(wordId);
      
      if (response.success) {
        // 更新进度
        setProgress(prev => ({
          ...prev,
          mastered: response.data.masteredCount,
          remaining: prev.remaining - 1,
          percentage: response.data.progress
        }));
        
        // 从队列中移除该词
        const newQueue = queue.filter(word => word.id !== wordId);
        setQueue(newQueue);
        
        // 调整当前索引
        if (currentIndex >= newQueue.length && newQueue.length > 0) {
          setCurrentIndex(newQueue.length - 1);
        }
        
        // 检查是否完成
        if (newQueue.length === 0) {
          setShowComplete(true);
        }
      }
    } catch (err) {
      console.error('标记熟词失败:', err);
    }
  };
  
  // 标记"过" - 暂时跳过，稍后随机位置复习
  const handlePass = async (wordId) => {
    try {
      const response = await studyAPI.markPassed(wordId);
      
      if (response.success) {
        // 标记为已"过"
        setPassedWords(prev => new Set([...prev, wordId]));
        
        // 从当前位置移除，稍后会在随机位置出现
        const currentWord = queue[currentIndex];
        const newQueue = queue.filter((word, idx) => !(idx === currentIndex));
        
        // 在当前位置插入"过"的词（模拟随机位置，实际由后端控制）
        // 这里我们在5-15个位置后插入
        const insertPosition = Math.min(currentIndex + Math.floor(Math.random() * 10) + 5, newQueue.length);
        newQueue.splice(insertPosition, 0, currentWord);
        
        setQueue(newQueue);
        
        // 保持在当前位置（显示下一个词）
        if (currentIndex >= newQueue.length - 1) {
          setCurrentIndex(0);
        }
      }
    } catch (err) {
      console.error('标记"过"失败:', err);
    }
  };
  
  // 下一个
  const handleNext = () => {
    if (currentIndex < queue.length - 1) {
      setCurrentIndex(prev => prev + 1);
    } else {
      // 循环到第一个
      setCurrentIndex(0);
    }
  };
  
  // 上一个
  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
    } else {
      // 循环到最后一个
      setCurrentIndex(queue.length - 1);
    }
  };
  
  // 切换随机模式
  const toggleShuffle = () => {
    const newShuffle = !shuffle;
    setShuffle(newShuffle);
    loadQueue(newShuffle);
  };
  
  // 重置进度
  const handleReset = async () => {
    if (window.confirm('确定要重置所有学习进度吗？')) {
      try {
        await studyAPI.reset();
        loadQueue(shuffle);
      } catch (err) {
        console.error('重置失败:', err);
      }
    }
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">加载中...</p>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <AlertCircle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-gray-700 mb-4">{error}</p>
          <button 
            onClick={() => loadQueue(shuffle)}
            className="px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600"
          >
            重新加载
          </button>
        </div>
      </div>
    );
  }
  
  if (showComplete) {
    return (
      <motion.div 
        className="flex items-center justify-center min-h-[500px]"
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
      >
        <div className="text-center max-w-md mx-auto p-8">
          <div className="w-24 h-24 bg-gradient-to-br from-yellow-400 to-orange-500 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
            <Trophy className="w-12 h-12 text-white" />
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-2">🎉 恭喜完成！</h2>
          <p className="text-gray-600 mb-6">
            你已经掌握了所有词汇！<br/>
            可以重置进度重新开始，或复习易错易混词汇。
          </p>
          <div className="flex gap-3 justify-center">
            <button
              onClick={handleReset}
              className="flex items-center gap-2 px-6 py-3 bg-primary-500 text-white rounded-xl hover:bg-primary-600 transition-colors"
            >
              <RotateCcw size={18} />
              重新开始
            </button>
          </div>
        </div>
      </motion.div>
    );
  }
  
  const currentWord = queue[currentIndex];
  
  return (
    <div className="py-4 sm:py-6 px-2 sm:px-4">
      {/* 控制栏 */}
      <div className="max-w-2xl mx-auto mb-4 sm:mb-6 flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-2 sm:gap-0">
        <div className="flex items-center gap-2">
          <button
            onClick={toggleShuffle}
            className={`flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm transition-colors ${
              shuffle 
                ? 'bg-purple-100 text-purple-700' 
                : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
            }`}
          >
            <Shuffle size={14} className="sm:w-4 sm:h-4" />
            {shuffle ? '随机' : '顺序'}
          </button>
        </div>
        
        <div className="text-xs sm:text-sm text-gray-500 text-center">
          {progress && (
            <span>{getProgressMessage(progress.percentage)}</span>
          )}
        </div>
        
        <button
          onClick={handleReset}
          className="flex items-center justify-center gap-1.5 px-3 py-2 rounded-lg text-xs sm:text-sm text-gray-600 hover:bg-gray-100 transition-colors"
        >
          <RotateCcw size={14} className="sm:w-4 sm:h-4" />
          重置
        </button>
      </div>
      
      {/* 功能说明 */}
      <div className="max-w-2xl mx-auto mb-3 sm:mb-4">
        <div className="flex items-center justify-center gap-4 sm:gap-6 text-xs text-gray-500 bg-gray-50 rounded-lg py-2 px-3">
          <span className="flex items-center gap-1.5">
            <span className="w-5 h-5 rounded bg-yellow-100 text-yellow-700 flex items-center justify-center text-xs font-medium">过</span>
            稍后复习
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-5 h-5 rounded bg-green-500 text-white flex items-center justify-center text-xs font-medium">斩</span>
            完全掌握
          </span>
        </div>
      </div>
      
      {/* 单词卡片 */}
      <AnimatePresence mode="wait">
        {currentWord && (
          <motion.div
            key={currentWord.id}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            transition={{ duration: 0.2 }}
          >
            <WordCard
              word={currentWord}
              onMaster={handleMaster}
              onPass={handlePass}
              onNext={handleNext}
              onPrev={handlePrev}
              hasNext={queue.length > 1}
              hasPrev={queue.length > 1}
              currentIndex={currentIndex}
              totalCount={queue.length}
              isMastered={false}
              isPassed={passedWords.has(currentWord.id)}
            />
          </motion.div>
        )}
      </AnimatePresence>
      
      {/* 进度条 */}
      {progress && (
        <div className="max-w-2xl mx-auto mt-4 sm:mt-6 px-2 sm:px-0">
          <div className="flex items-center justify-between text-xs text-gray-500 mb-1.5 sm:mb-2">
            <span>学习进度</span>
            <span>{progress.mastered}/{progress.total} ({progress.percentage}%)</span>
          </div>
          <div className="h-2 sm:h-2.5 bg-gray-200 rounded-full overflow-hidden">
            <motion.div 
              className="h-full bg-gradient-to-r from-primary-500 to-primary-400 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress.percentage}%` }}
              transition={{ duration: 0.5 }}
            />
          </div>
          <div className="flex items-center justify-between text-xs text-gray-400 mt-1.5">
            <span>剩余 {progress.remaining} 词</span>
            <span>已掌握 {progress.mastered} 词</span>
          </div>
        </div>
      )}
    </div>
  );
};

export default StudyMode;
