import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { AlertTriangle, Search, BookOpen } from 'lucide-react';
import ConfusableCard from './ConfusableCard';
import { confusableAPI } from '../utils/api';

const ConfusableMode = () => {
  const [groups, setGroups] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredGroups, setFilteredGroups] = useState([]);
  
  useEffect(() => {
    loadConfusableGroups();
  }, []);
  
  useEffect(() => {
    if (searchTerm.trim() === '') {
      setFilteredGroups(groups);
    } else {
      const filtered = groups.filter(group => 
        group.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        group.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
        group.words.some(word => 
          word.word.toLowerCase().includes(searchTerm.toLowerCase())
        )
      );
      setFilteredGroups(filtered);
    }
  }, [searchTerm, groups]);
  
  const loadConfusableGroups = async () => {
    try {
      setLoading(true);
      const response = await confusableAPI.getAll();
      
      if (response.success) {
        setGroups(response.data);
        setFilteredGroups(response.data);
      } else {
        setError('加载失败');
      }
    } catch (err) {
      setError('网络错误');
    } finally {
      setLoading(false);
    }
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-amber-200 border-t-amber-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">加载中...</p>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <AlertTriangle className="w-12 h-12 text-red-500 mx-auto mb-4" />
          <p className="text-gray-700">{error}</p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="py-6 px-4 max-w-4xl mx-auto">
      {/* 标题区 */}
      <motion.div 
        className="text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-amber-100 rounded-full mb-4">
          <AlertTriangle className="text-amber-600" size={20} />
          <span className="text-amber-800 font-medium">易错易混词汇辨析</span>
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          攻克相似词汇陷阱
        </h2>
        <p className="text-gray-600 max-w-lg mx-auto">
          四级考试中容易混淆的词汇组合，通过对比学习加深记忆，避免考试失误
        </p>
      </motion.div>
      
      {/* 搜索栏 */}
      <div className="mb-6">
        <div className="relative max-w-md mx-auto">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={20} />
          <input
            type="text"
            placeholder="搜索易混词汇..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 rounded-xl border border-gray-200 focus:border-primary-500 focus:ring-2 focus:ring-primary-200 outline-none transition-all"
          />
        </div>
      </div>
      
      {/* 统计信息 */}
      <div className="flex items-center justify-center gap-6 mb-6 text-sm text-gray-500">
        <div className="flex items-center gap-1">
          <BookOpen size={16} />
          <span>共 {groups.length} 组易混词汇</span>
        </div>
        {searchTerm && (
          <div>
            搜索结果: {filteredGroups.length} 组
          </div>
        )}
      </div>
      
      {/* 词汇组列表 */}
      <div className="space-y-4">
        {filteredGroups.length > 0 ? (
          filteredGroups.map((group, index) => (
            <motion.div
              key={group.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.05 }}
            >
              <ConfusableCard group={group} />
            </motion.div>
          ))
        ) : (
          <div className="text-center py-12">
            <AlertTriangle className="w-12 h-12 text-gray-300 mx-auto mb-4" />
            <p className="text-gray-500">没有找到匹配的词汇组</p>
          </div>
        )}
      </div>
      
      {/* 学习提示 */}
      <motion.div 
        className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-xl border border-blue-100"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.3 }}
      >
        <h3 className="font-bold text-blue-800 mb-3">💡 辨析学习技巧</h3>
        <ul className="space-y-2 text-sm text-gray-700">
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">1.</span>
            <span><strong>对比记忆：</strong>将易混词放在一起对比，找出核心差异点</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">2.</span>
            <span><strong>语境区分：</strong>通过例句理解不同词汇的使用场景</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">3.</span>
            <span><strong>词根分析：</strong>理解词根词缀差异，从根本上区分</span>
          </li>
          <li className="flex items-start gap-2">
            <span className="text-blue-500 mt-0.5">4.</span>
            <span><strong>反复测试：</strong>定期自测，强化记忆</span>
          </li>
        </ul>
      </motion.div>
    </div>
  );
};

export default ConfusableMode;
