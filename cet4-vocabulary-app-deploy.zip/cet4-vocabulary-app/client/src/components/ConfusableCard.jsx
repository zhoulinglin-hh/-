import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronDown, ChevronUp, AlertTriangle, BookOpen } from 'lucide-react';

const ConfusableCard = ({ group, onWordClick }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const [expandedWord, setExpandedWord] = useState(null);
  
  return (
    <motion.div 
      className="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100"
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      whileHover={{ shadow: '0 10px 25px -5px rgba(0, 0, 0, 0.1)' }}
    >
      {/* 标题栏 */}
      <div 
        className="p-4 bg-gradient-to-r from-amber-50 to-orange-50 cursor-pointer"
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="text-amber-500" size={20} />
            <h3 className="font-bold text-gray-800">{group.title}</h3>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 bg-white px-2 py-1 rounded-full">
              {group.words.length} 个词
            </span>
            {isExpanded ? (
              <ChevronUp className="text-gray-400" size={18} />
            ) : (
              <ChevronDown className="text-gray-400" size={18} />
            )}
          </div>
        </div>
        <p className="text-sm text-gray-600 mt-1">{group.description}</p>
      </div>
      
      {/* 展开内容 */}
      {isExpanded && (
        <motion.div 
          className="p-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="space-y-3">
            {group.words.map((wordItem, idx) => (
              <div 
                key={idx}
                className="border border-gray-100 rounded-lg p-3 hover:bg-gray-50 transition-colors cursor-pointer"
                onClick={() => setExpandedWord(expandedWord === idx ? null : idx)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <span className="text-lg font-bold text-primary-600">
                      {wordItem.word}
                    </span>
                    <span className="text-sm text-gray-600">
                      {wordItem.definition}
                    </span>
                  </div>
                  {expandedWord === idx ? (
                    <ChevronUp className="text-gray-400" size={16} />
                  ) : (
                    <ChevronDown className="text-gray-400" size={16} />
                  )}
                </div>
                
                {expandedWord === idx && (
                  <motion.div 
                    className="mt-3 pt-3 border-t border-gray-100 space-y-2"
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                  >
                    <div className="flex items-start gap-2">
                      <BookOpen size={14} className="text-primary-500 mt-1" />
                      <p className="text-sm text-gray-700 italic">
                        {wordItem.example}
                      </p>
                    </div>
                    <div className="bg-amber-50 rounded p-2 text-xs text-amber-700">
                      <strong>辨析要点：</strong>{wordItem.note}
                    </div>
                  </motion.div>
                )}
              </div>
            ))}
          </div>
          
          {/* 总结辨析 */}
          <div className="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-100">
            <h4 className="text-sm font-semibold text-blue-700 mb-1">📝 辨析总结</h4>
            <p className="text-sm text-gray-700">{group.distinction}</p>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default ConfusableCard;
