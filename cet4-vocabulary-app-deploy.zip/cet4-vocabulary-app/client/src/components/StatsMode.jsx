import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { BarChart2, RefreshCw } from 'lucide-react';
import FrequencyChart from './FrequencyChart';
import { statsAPI } from '../utils/api';

const StatsMode = () => {
  const [distribution, setDistribution] = useState(null);
  const [userStats, setUserStats] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  useEffect(() => {
    loadStats();
  }, []);
  
  const loadStats = async () => {
    try {
      setLoading(true);
      setError(null);
      
      // 并行获取数据
      const [distRes, userRes] = await Promise.all([
        statsAPI.getFrequencyDistribution(),
        statsAPI.getUserStats()
      ]);
      
      if (distRes.success) {
        setDistribution(distRes.data);
      }
      
      if (userRes.success) {
        setUserStats(userRes.data);
      }
    } catch (err) {
      setError('加载统计数据失败');
    } finally {
      setLoading(false);
    }
  };
  
  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-primary-200 border-t-primary-500 rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-gray-500">加载统计数据...</p>
        </div>
      </div>
    );
  }
  
  if (error) {
    return (
      <div className="flex items-center justify-center h-96">
        <div className="text-center">
          <p className="text-gray-700 mb-4">{error}</p>
          <button 
            onClick={loadStats}
            className="flex items-center gap-2 px-4 py-2 bg-primary-500 text-white rounded-lg hover:bg-primary-600 mx-auto"
          >
            <RefreshCw size={16} />
            重新加载
          </button>
        </div>
      </div>
    );
  }
  
  return (
    <div className="py-6 px-4 max-w-5xl mx-auto">
      {/* 标题区 */}
      <motion.div 
        className="text-center mb-8"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-primary-100 rounded-full mb-4">
          <BarChart2 className="text-primary-600" size={20} />
          <span className="text-primary-800 font-medium">考频观测中心</span>
        </div>
        <h2 className="text-2xl font-bold text-gray-800 mb-2">
          四级词汇考频数据分析
        </h2>
        <p className="text-gray-600 max-w-lg mx-auto">
          基于历年四级考试真题统计，科学规划学习重点，高效备考
        </p>
      </motion.div>
      
      {/* 图表组件 */}
      {distribution && (
        <FrequencyChart 
          distribution={distribution} 
          userStats={userStats}
        />
      )}
      
      {/* 考频等级说明 */}
      <motion.div 
        className="mt-8 grid grid-cols-2 md:grid-cols-5 gap-3"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.5 }}
      >
        {[
          { level: 5, label: '极高频', color: 'bg-red-500', desc: '必背' },
          { level: 4, label: '高频', color: 'bg-orange-500', desc: '重点' },
          { level: 3, label: '中频', color: 'bg-yellow-500', desc: '掌握' },
          { level: 2, label: '低频', color: 'bg-green-500', desc: '了解' },
          { level: 1, label: '极低频', color: 'bg-gray-500', desc: '可选' }
        ].map((item) => (
          <div 
            key={item.level}
            className="bg-white rounded-lg p-3 shadow-sm border border-gray-100 text-center"
          >
            <div className={`w-8 h-8 ${item.color} rounded-full mx-auto mb-2 flex items-center justify-center text-white font-bold text-sm`}>
              {item.level}
            </div>
            <p className="font-medium text-gray-800 text-sm">{item.label}</p>
            <p className="text-xs text-gray-500">{item.desc}</p>
          </div>
        ))}
      </motion.div>
      
      {/* 刷新按钮 */}
      <div className="mt-8 text-center">
        <button
          onClick={loadStats}
          className="inline-flex items-center gap-2 px-4 py-2 text-gray-500 hover:text-primary-600 transition-colors"
        >
          <RefreshCw size={16} />
          刷新数据
        </button>
      </div>
    </div>
  );
};

export default StatsMode;
