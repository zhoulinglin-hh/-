import React from 'react';
import { motion } from 'framer-motion';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend
} from 'recharts';
import { TrendingUp, Target, BookOpen, Award } from 'lucide-react';

const FrequencyChart = ({ distribution, userStats }) => {
  const frequencyLabels = {
    5: '极高频',
    4: '高频',
    3: '中频',
    2: '低频',
    1: '极低频'
  };
  
  const frequencyColors = {
    5: '#dc2626',
    4: '#ea580c',
    3: '#ca8a04',
    2: '#16a34a',
    1: '#6b7280'
  };
  
  // 准备图表数据
  const chartData = Object.entries(distribution.distribution).map(([level, count]) => ({
    level: parseInt(level),
    name: frequencyLabels[level],
    count,
    color: frequencyColors[level]
  }));
  
  // 计算统计数据
  const totalWords = distribution.total;
  const highFreqWords = (distribution.distribution[5] || 0) + (distribution.distribution[4] || 0);
  const highFreqPercentage = Math.round((highFreqWords / totalWords) * 100);
  
  return (
    <div className="space-y-6">
      {/* 统计卡片 */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <motion.div 
          className="bg-white rounded-xl p-4 shadow-md border border-gray-100"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
        >
          <div className="flex items-center gap-2 mb-2">
            <BookOpen className="text-primary-500" size={20} />
            <span className="text-sm text-gray-500">总词汇量</span>
          </div>
          <p className="text-2xl font-bold text-gray-800">{totalWords}</p>
          <p className="text-xs text-gray-400 mt-1">四级核心词汇</p>
        </motion.div>
        
        <motion.div 
          className="bg-white rounded-xl p-4 shadow-md border border-gray-100"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <div className="flex items-center gap-2 mb-2">
            <Target className="text-red-500" size={20} />
            <span className="text-sm text-gray-500">高频词汇</span>
          </div>
          <p className="text-2xl font-bold text-gray-800">{highFreqWords}</p>
          <p className="text-xs text-gray-400 mt-1">占比 {highFreqPercentage}%</p>
        </motion.div>
        
        {userStats && (
          <>
            <motion.div 
              className="bg-white rounded-xl p-4 shadow-md border border-gray-100"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <TrendingUp className="text-green-500" size={20} />
                <span className="text-sm text-gray-500">已掌握</span>
              </div>
              <p className="text-2xl font-bold text-gray-800">{userStats.masteredCount}</p>
              <p className="text-xs text-gray-400 mt-1">{userStats.overallProgress}% 完成度</p>
            </motion.div>
            
            <motion.div 
              className="bg-white rounded-xl p-4 shadow-md border border-gray-100"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
            >
              <div className="flex items-center gap-2 mb-2">
                <Award className="text-amber-500" size={20} />
                <span className="text-sm text-gray-500">待学习</span>
              </div>
              <p className="text-2xl font-bold text-gray-800">{userStats.remainingCount}</p>
              <p className="text-xs text-gray-400 mt-1">继续加油！</p>
            </motion.div>
          </>
        )}
      </div>
      
      {/* 图表区域 */}
      <div className="grid md:grid-cols-2 gap-6">
        {/* 柱状图 */}
        <motion.div 
          className="bg-white rounded-xl p-6 shadow-md border border-gray-100"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h3 className="text-lg font-bold text-gray-800 mb-4">📊 考频分布</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis type="number" />
                <YAxis 
                  dataKey="name" 
                  type="category" 
                  width={60}
                  tick={{ fontSize: 12 }}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: '#fff', 
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px'
                  }}
                />
                <Bar dataKey="count" radius={[0, 4, 4, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
        
        {/* 饼图 */}
        <motion.div 
          className="bg-white rounded-xl p-6 shadow-md border border-gray-100"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-lg font-bold text-gray-800 mb-4">🥧 考频占比</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="count"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </motion.div>
      </div>
      
      {/* 学习建议 */}
      <motion.div 
        className="bg-gradient-to-r from-primary-50 to-blue-50 rounded-xl p-6 border border-primary-100"
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <h3 className="text-lg font-bold text-primary-800 mb-3">💡 学习策略建议</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <h4 className="font-semibold text-primary-700">优先级排序</h4>
            <ul className="space-y-1 text-sm text-gray-700">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500"></span>
                <span><strong>极高频词</strong> - 必须完全掌握，会读会写会用</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-orange-500"></span>
                <span><strong>高频词</strong> - 重点记忆，理解多种用法</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-yellow-500"></span>
                <span><strong>中频词</strong> - 理解含义，能识别即可</span>
              </li>
            </ul>
          </div>
          <div className="space-y-2">
            <h4 className="font-semibold text-primary-700">记忆技巧</h4>
            <ul className="space-y-1 text-sm text-gray-700">
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary-500"></span>
                <span>结合词根词缀记忆，举一反三</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary-500"></span>
                <span>通过例句理解用法和搭配</span>
              </li>
              <li className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-primary-500"></span>
                <span>对比近义词反义词加深理解</span>
              </li>
            </ul>
          </div>
        </div>
      </motion.div>
      
      {/* 用户进度详情（如果有） */}
      {userStats && userStats.masteryRateByFrequency && (
        <motion.div 
          className="bg-white rounded-xl p-6 shadow-md border border-gray-100"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.5 }}
        >
          <h3 className="text-lg font-bold text-gray-800 mb-4">📈 各考频掌握情况</h3>
          <div className="space-y-3">
            {userStats.masteryRateByFrequency.map((item) => (
              <div key={item.level} className="flex items-center gap-4">
                <div className="w-20 text-sm font-medium text-gray-600">
                  {frequencyLabels[item.level]}
                </div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-100 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full rounded-full transition-all duration-500"
                      style={{ 
                        backgroundColor: frequencyColors[item.level],
                        width: `${item.rate}%`
                      }}
                      initial={{ width: 0 }}
                      animate={{ width: `${item.rate}%` }}
                    />
                  </div>
                </div>
                <div className="w-24 text-right text-sm text-gray-600">
                  {item.mastered}/{item.total} ({item.rate}%)
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default FrequencyChart;
