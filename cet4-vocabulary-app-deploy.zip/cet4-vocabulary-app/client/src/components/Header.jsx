import React from 'react';
import { motion } from 'framer-motion';
import { BookOpen, BarChart2, AlertTriangle } from 'lucide-react';

const Header = ({ activeTab, setActiveTab, progress }) => {
  const tabs = [
    { id: 'study', label: '背诵卡', icon: BookOpen },
    { id: 'confusable', label: '易错易混', icon: AlertTriangle },
    { id: 'stats', label: '考频观测', icon: BarChart2 },
  ];
  
  return (
    <header className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-4xl mx-auto px-4">
        {/* 顶部标题栏 */}
        <div className="flex items-center justify-between py-3">
          <div className="flex items-center gap-2">
            <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-primary-600 rounded-xl flex items-center justify-center shadow-lg shadow-primary-200">
              <BookOpen className="text-white" size={22} />
            </div>
            <div>
              <h1 className="text-lg font-bold text-gray-800">四级词汇</h1>
              <p className="text-xs text-gray-500">CET4 Vocabulary</p>
            </div>
          </div>
          
          {/* 进度显示 */}
          {progress && (
            <div className="flex items-center gap-3">
              <div className="text-right hidden sm:block">
                <p className="text-xs text-gray-500">学习进度</p>
                <p className="text-sm font-semibold text-primary-600">
                  {progress.mastered}/{progress.total}
                </p>
              </div>
              <div className="w-16 h-16 relative">
                <svg className="w-full h-full transform -rotate-90">
                  <circle
                    cx="32"
                    cy="32"
                    r="28"
                    stroke="#e5e7eb"
                    strokeWidth="4"
                    fill="none"
                  />
                  <circle
                    cx="32"
                    cy="32"
                    r="28"
                    stroke="#0ea5e9"
                    strokeWidth="4"
                    fill="none"
                    strokeLinecap="round"
                    style={{
                      strokeDasharray: `${2 * Math.PI * 28}`,
                      strokeDashoffset: `${2 * Math.PI * 28 * (1 - progress.percentage / 100)}`,
                      transition: 'stroke-dashoffset 0.5s ease'
                    }}
                  />
                </svg>
                <div className="absolute inset-0 flex items-center justify-center">
                  <span className="text-xs font-bold text-primary-600">
                    {progress.percentage}%
                  </span>
                </div>
              </div>
            </div>
          )}
        </div>
        
        {/* 导航标签 */}
        <nav className="flex gap-1 -mb-px">
          {tabs.map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-medium transition-colors relative ${
                  isActive 
                    ? 'text-primary-600' 
                    : 'text-gray-500 hover:text-gray-700'
                }`}
              >
                <Icon size={18} />
                <span className="hidden sm:inline">{tab.label}</span>
                {isActive && (
                  <motion.div
                    className="absolute bottom-0 left-0 right-0 h-0.5 bg-primary-500"
                    layoutId="activeTab"
                    transition={{ type: 'spring', stiffness: 500, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </nav>
      </div>
    </header>
  );
};

export default Header;
