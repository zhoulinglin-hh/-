import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Volume2, 
  CheckCircle, 
  ChevronLeft, 
  ChevronRight,
  BookOpen,
  AlertCircle,
  SkipForward,
  Sword
} from 'lucide-react';
import { getFrequencyHint, getStudyAdvice, speakWord } from '../utils/helpers';

const WordCard = ({ 
  word, 
  onMaster, 
  onPass,
  onNext, 
  onPrev, 
  hasNext, 
  hasPrev,
  currentIndex,
  totalCount,
  isMastered = false,
  isPassed = false,
  isReviewMode = false
}) => {
  const [showAdvice, setShowAdvice] = useState(false);
  
  if (!word) return null;
  
  const frequencyHint = getFrequencyHint(word.frequency);
  const studyAdvice = getStudyAdvice(word.frequency);
  
  const handleSpeak = () => {
    speakWord(word.word);
  };
  
  const handleMaster = () => {
    onMaster(word.id);
  };
  
  const handlePass = () => {
    onPass(word.id);
  };
  
  return (
    <div className="w-full max-w-2xl mx-auto px-2 sm:px-0">
      {/* 进度指示器 */}
      <div className="mb-3 sm:mb-4 flex items-center justify-between text-xs sm:text-sm text-gray-600">
        <span className="font-medium">
          {currentIndex + 1} / {totalCount}
        </span>
        <div className="flex items-center gap-1 sm:gap-2">
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${frequencyHint.bgColor} ${frequencyHint.color}`}>
            {frequencyHint.stars}
          </span>
          {isMastered && (
            <span className="px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700 flex items-center gap-1">
              <CheckCircle size={10} />
              <span className="hidden sm:inline">已掌握</span>
            </span>
          )}
          {isPassed && !isMastered && (
            <span className="px-2 py-1 rounded-full text-xs font-medium bg-yellow-100 text-yellow-700 flex items-center gap-1">
              <SkipForward size={10} />
              <span className="hidden sm:inline">待复习</span>
            </span>
          )}
        </div>
      </div>
      
      {/* 主卡片 */}
      <motion.div 
        className="bg-white rounded-xl sm:rounded-2xl shadow-lg sm:shadow-xl overflow-hidden"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        {/* 顶部：单词和音标 */}
        <div className="bg-gradient-to-r from-primary-500 to-primary-600 p-4 sm:p-6 text-white">
          <div className="flex items-center justify-between">
            <div className="min-w-0 flex-1">
              <h2 className="text-2xl sm:text-4xl font-bold mb-1 sm:mb-2 truncate">{word.word}</h2>
              <p className="text-sm sm:text-lg text-primary-100 flex items-center gap-2">
                <span className="truncate">{word.phonetic}</span>
                <button 
                  onClick={handleSpeak}
                  className="p-1.5 sm:p-2 rounded-full hover:bg-white/20 transition-colors flex-shrink-0"
                  title="播放发音"
                >
                  <Volume2 size={16} className="sm:w-5 sm:h-5" />
                </button>
              </p>
            </div>
            <div className={`px-2 sm:px-3 py-1.5 sm:py-2 rounded-lg ${frequencyHint.bgColor} ${frequencyHint.color} text-xs sm:text-sm font-medium flex-shrink-0 ml-2`}>
              {frequencyHint.text}
            </div>
          </div>
        </div>
        
        {/* 中间：主要内容 - 可滚动区域 */}
        <div className="p-3 sm:p-6 space-y-3 sm:space-y-4 max-h-[50vh] sm:max-h-none overflow-y-auto">
          {/* 释义 */}
          <div className="border-l-4 border-primary-500 pl-3 sm:pl-4">
            <h3 className="text-xs sm:text-sm font-semibold text-gray-500 mb-1 flex items-center gap-1">
              <BookOpen size={12} className="sm:w-4 sm:h-4" />
              释义
            </h3>
            <p className="text-base sm:text-lg text-gray-800">{word.definition}</p>
          </div>
          
          {/* 词根衍生 */}
          <div className="bg-amber-50 rounded-lg p-3 sm:p-4 border border-amber-100">
            <h3 className="text-xs sm:text-sm font-semibold text-amber-700 mb-1 sm:mb-2">📚 词根衍生</h3>
            <p className="text-gray-700 text-xs sm:text-sm leading-relaxed">{word.rootDerivatives}</p>
          </div>
          
          {/* 近义词和反义词 */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4">
            <div className="bg-green-50 rounded-lg p-2.5 sm:p-3 border border-green-100">
              <h3 className="text-xs sm:text-sm font-semibold text-green-700 mb-1 sm:mb-2">🔄 近义词</h3>
              <div className="flex flex-wrap gap-1">
                {word.synonyms.map((syn, idx) => (
                  <span 
                    key={idx}
                    className="px-2 py-0.5 sm:py-1 bg-green-100 text-green-700 rounded text-xs"
                  >
                    {syn}
                  </span>
                ))}
              </div>
            </div>
            <div className="bg-red-50 rounded-lg p-2.5 sm:p-3 border border-red-100">
              <h3 className="text-xs sm:text-sm font-semibold text-red-700 mb-1 sm:mb-2">⛔ 反义词</h3>
              <div className="flex flex-wrap gap-1">
                {word.antonyms.map((ant, idx) => (
                  <span 
                    key={idx}
                    className="px-2 py-0.5 sm:py-1 bg-red-100 text-red-700 rounded text-xs"
                  >
                    {ant}
                  </span>
                ))}
              </div>
            </div>
          </div>
          
          {/* 例句 */}
          <div className="bg-blue-50 rounded-lg p-3 sm:p-4 border border-blue-100">
            <h3 className="text-xs sm:text-sm font-semibold text-blue-700 mb-1 sm:mb-2">💬 例句</h3>
            <p className="text-gray-700 text-xs sm:text-sm leading-relaxed italic">
              {word.example}
            </p>
          </div>
          
          {/* 学习建议（可展开） */}
          <AnimatePresence>
            {showAdvice && (
              <motion.div
                initial={{ opacity: 0, height: 0 }}
                animate={{ opacity: 1, height: 'auto' }}
                exit={{ opacity: 0, height: 0 }}
                className="bg-purple-50 rounded-lg p-3 sm:p-4 border border-purple-100 overflow-hidden"
              >
                <h3 className="text-xs sm:text-sm font-semibold text-purple-700 mb-1 sm:mb-2 flex items-center gap-1">
                  <AlertCircle size={12} className="sm:w-4 sm:h-4" />
                  学习建议
                </h3>
                <ul className="space-y-1">
                  {studyAdvice.map((advice, idx) => (
                    <li key={idx} className="text-xs sm:text-sm text-gray-700 flex items-start gap-2">
                      <span className="text-purple-500 mt-1">•</span>
                      {advice}
                    </li>
                  ))}
                </ul>
              </motion.div>
            )}
          </AnimatePresence>
          
          {/* 提示词 */}
          <div className={`p-2.5 sm:p-3 rounded-lg ${frequencyHint.bgColor} ${frequencyHint.borderColor} border`}>
            <p className={`text-xs sm:text-sm ${frequencyHint.color} font-medium`}>
              💡 {frequencyHint.description}
            </p>
          </div>
        </div>
        
        {/* 底部：操作按钮 */}
        <div className="p-3 sm:p-4 bg-gray-50 border-t border-gray-100">
          {/* 导航按钮 - 手机端垂直排列，电脑端水平排列 */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 sm:gap-3">
            {/* 上一个按钮 */}
            <button
              onClick={onPrev}
              disabled={!hasPrev}
              className="flex items-center justify-center gap-2 px-4 py-3 sm:py-2 rounded-lg bg-white border-2 border-gray-200 text-gray-700 hover:bg-gray-50 hover:border-gray-300 disabled:opacity-40 disabled:cursor-not-allowed transition-all font-medium text-sm sm:text-base"
            >
              <ChevronLeft size={20} />
              <span>上一个</span>
            </button>
            
            {/* 中间操作区 */}
            <div className="flex-1 flex flex-col sm:flex-row items-stretch sm:items-center justify-center gap-2">
              {/* 学习建议按钮 */}
              <button
                onClick={() => setShowAdvice(!showAdvice)}
                className={`px-3 py-2.5 sm:py-2 rounded-lg text-xs sm:text-sm font-medium transition-colors ${
                  showAdvice 
                    ? 'bg-purple-100 text-purple-700' 
                    : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'
                }`}
              >
                学习建议
              </button>
              
              {/* 过和斩按钮 */}
              {!isMastered && !isReviewMode && (
                <div className="flex gap-2">
                  {/* 过按钮 - 暂时跳过 */}
                  <button
                    onClick={handlePass}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 rounded-lg bg-yellow-100 text-yellow-700 hover:bg-yellow-200 transition-colors font-medium text-sm"
                    title="暂时跳过，稍后复习"
                  >
                    <SkipForward size={16} />
                    <span>过</span>
                  </button>
                  
                  {/* 斩按钮 - 完全掌握 */}
                  <button
                    onClick={handleMaster}
                    className="flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 rounded-lg bg-green-500 text-white hover:bg-green-600 transition-colors font-medium text-sm shadow-md hover:shadow-lg"
                    title="已掌握，从学习队列移除"
                  >
                    <Sword size={16} />
                    <span>斩</span>
                  </button>
                </div>
              )}
              
              {isMastered && (
                <span className="flex items-center justify-center gap-1.5 px-4 py-2.5 sm:py-2 rounded-lg bg-green-100 text-green-700 font-medium text-sm">
                  <CheckCircle size={16} />
                  <span>已掌握</span>
                </span>
              )}
            </div>
            
            {/* 下一个按钮 */}
            <button
              onClick={onNext}
              disabled={!hasNext}
              className="flex items-center justify-center gap-2 px-4 py-3 sm:py-2 rounded-lg bg-primary-500 text-white hover:bg-primary-600 disabled:opacity-40 disabled:cursor-not-allowed transition-all font-medium text-sm sm:text-base shadow-md hover:shadow-lg"
            >
              <span>下一个</span>
              <ChevronRight size={20} />
            </button>
          </div>
          
          {/* 按钮说明 */}
          {!isMastered && !isReviewMode && (
            <div className="mt-2 flex items-center justify-center gap-4 text-xs text-gray-500">
              <span className="flex items-center gap-1">
                <SkipForward size={12} />
                过：稍后复习
              </span>
              <span className="flex items-center gap-1">
                <Sword size={12} />
                斩：完全掌握
              </span>
            </div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default WordCard;
