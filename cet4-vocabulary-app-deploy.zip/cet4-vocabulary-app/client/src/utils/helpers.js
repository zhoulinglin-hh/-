// 考频提示词生成
export const getFrequencyHint = (frequency) => {
  const hints = {
    5: {
      text: '考频极高 · 必背单词',
      description: '历年四级考试高频出现，务必熟练掌握！',
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      borderColor: 'border-red-200',
      stars: '★★★★★'
    },
    4: {
      text: '考频较高 · 重点记忆',
      description: '常考词汇，建议重点复习掌握。',
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
      borderColor: 'border-orange-200',
      stars: '★★★★☆'
    },
    3: {
      text: '考频中等 · 需要掌握',
      description: '中等频率出现，建议理解并记忆。',
      color: 'text-yellow-600',
      bgColor: 'bg-yellow-50',
      borderColor: 'border-yellow-200',
      stars: '★★★☆☆'
    },
    2: {
      text: '考频较低 · 了解即可',
      description: '偶尔出现，理解基本含义即可。',
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      borderColor: 'border-green-200',
      stars: '★★☆☆☆'
    },
    1: {
      text: '考频极低 · 可选记忆',
      description: '极少出现，有余力时再学习。',
      color: 'text-gray-600',
      bgColor: 'bg-gray-50',
      borderColor: 'border-gray-200',
      stars: '★☆☆☆☆'
    }
  };
  
  return hints[frequency] || hints[3];
};

// 根据考频生成学习建议
export const getStudyAdvice = (frequency) => {
  const advice = {
    5: [
      '这是极高频词汇，必须做到：会读、会写、会用',
      '建议制作单词卡片，每天复习3-5次',
      '尝试用该词造3个不同语境的句子',
      '重点关注其近义词和反义词的辨析'
    ],
    4: [
      '高频词汇，需要熟练掌握拼写和用法',
      '结合例句记忆，理解常见搭配',
      '注意词根词缀，帮助记忆相关衍生词'
    ],
    3: [
      '中频词汇，理解含义并能识别即可',
      '通过阅读真题文章加深印象',
      '重点关注在语境中的用法'
    ],
    2: [
      '低频词汇，了解基本含义',
      '不必花太多时间，浏览记忆即可',
      '遇到时能够认识就行'
    ],
    1: [
      '极低频词汇，学有余力时再关注',
      '可暂时跳过，优先掌握高频词汇'
    ]
  };
  
  return advice[frequency] || advice[3];
};

// 格式化进度百分比
export const formatProgress = (current, total) => {
  if (total === 0) return 0;
  return Math.round((current / total) * 100);
};

// 生成学习进度提示
export const getProgressMessage = (percentage) => {
  if (percentage === 0) return '🚀 开始你的四级词汇之旅吧！';
  if (percentage < 20) return '🌱 起步阶段，坚持就是胜利！';
  if (percentage < 40) return '🌿 稳步前进，积累中...';
  if (percentage < 60) return '🌳 已经掌握一半了，继续加油！';
  if (percentage < 80) return '🏆 冲刺阶段，胜利在望！';
  if (percentage < 100) return '🎯 即将完成，最后冲刺！';
  return '🎉 恭喜！你已掌握所有词汇！';
};

// 随机打乱数组
export const shuffleArray = (array) => {
  const newArray = [...array];
  for (let i = newArray.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
  }
  return newArray;
};

// 本地存储工具
export const storage = {
  set: (key, value) => {
    try {
      localStorage.setItem(key, JSON.stringify(value));
    } catch (e) {
      console.error('Storage error:', e);
    }
  },
  get: (key, defaultValue = null) => {
    try {
      const item = localStorage.getItem(key);
      return item ? JSON.parse(item) : defaultValue;
    } catch (e) {
      return defaultValue;
    }
  },
  remove: (key) => {
    try {
      localStorage.removeItem(key);
    } catch (e) {
      console.error('Storage error:', e);
    }
  }
};

// 防抖函数
export const debounce = (func, wait) => {
  let timeout;
  return function executedFunction(...args) {
    const later = () => {
      clearTimeout(timeout);
      func(...args);
    };
    clearTimeout(timeout);
    timeout = setTimeout(later, wait);
  };
};

// 截断文本
export const truncateText = (text, maxLength) => {
  if (!text || text.length <= maxLength) return text;
  return text.substring(0, maxLength) + '...';
};

// 播放发音（使用 Web Speech API）
export const speakWord = (word, lang = 'en-US') => {
  if (!window.speechSynthesis) {
    console.warn('Speech synthesis not supported');
    return;
  }
  
  // 取消之前的语音
  window.speechSynthesis.cancel();
  
  const utterance = new SpeechSynthesisUtterance(word);
  utterance.lang = lang;
  utterance.rate = 0.8;
  utterance.pitch = 1;
  
  window.speechSynthesis.speak(utterance);
};

// 导出所有工具函数
const helpers = {
  getFrequencyHint,
  getStudyAdvice,
  formatProgress,
  getProgressMessage,
  shuffleArray,
  storage,
  debounce,
  truncateText,
  speakWord
};

export default helpers;
