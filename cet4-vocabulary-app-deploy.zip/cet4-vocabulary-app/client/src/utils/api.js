import axios from 'axios';

// API 基础配置
const api = axios.create({
  baseURL: process.env.NODE_ENV === 'production' ? '/api' : 'http://localhost:3001/api',
  timeout: 10000,
  headers: {
    'Content-Type': 'application/json'
  }
});

// 请求拦截器
api.interceptors.request.use(
  (config) => {
    // 从 localStorage 获取 userId
    const userId = localStorage.getItem('cet4_user_id');
    if (userId) {
      // 如果是 GET 请求，添加到 params
      if (config.method === 'get' && config.params) {
        config.params.userId = userId;
      } else if (config.method === 'get') {
        config.params = { userId };
      }
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// 响应拦截器
api.interceptors.response.use(
  (response) => response.data,
  (error) => {
    console.error('API Error:', error);
    return Promise.reject(error);
  }
);

// 用户相关
export const userAPI = {
  create: () => api.post('/user/create'),
  getOrCreateId: async () => {
    let userId = localStorage.getItem('cet4_user_id');
    if (!userId) {
      const res = await api.post('/user/create');
      if (res.success) {
        userId = res.userId;
        localStorage.setItem('cet4_user_id', userId);
      }
    }
    return userId;
  }
};

// 词汇相关
export const wordsAPI = {
  getAll: (params) => api.get('/words', { params }),
  search: (q) => api.get('/words/search', { params: { q } }),
  getHighFrequency: (limit = 20) => api.get('/words/high-frequency', { params: { limit } })
};

// 学习相关
export const studyAPI = {
  getQueue: (shuffle = false) => {
    const userId = localStorage.getItem('cet4_user_id');
    return api.get('/study/queue', { params: { userId, shuffle } });
  },
  markMastered: (wordId) => {
    const userId = localStorage.getItem('cet4_user_id');
    return api.post('/study/master', { userId, wordId });
  },
  markPassed: (wordId) => {
    const userId = localStorage.getItem('cet4_user_id');
    return api.post('/study/pass', { userId, wordId });
  },
  unmarkMastered: (wordId) => {
    const userId = localStorage.getItem('cet4_user_id');
    return api.post('/study/unmaster', { userId, wordId });
  },
  getMastered: () => {
    const userId = localStorage.getItem('cet4_user_id');
    return api.get('/study/mastered', { params: { userId } });
  },
  reset: () => {
    const userId = localStorage.getItem('cet4_user_id');
    return api.post('/study/reset', { userId });
  }
};

// 易错易混相关
export const confusableAPI = {
  getAll: () => api.get('/confusable'),
  getById: (id) => api.get(`/confusable/${id}`)
};

// 统计相关
export const statsAPI = {
  getFrequencyDistribution: () => api.get('/stats/frequency-distribution'),
  getUserStats: () => {
    const userId = localStorage.getItem('cet4_user_id');
    return api.get('/stats/user', { params: { userId } });
  }
};

// 健康检查
export const healthAPI = {
  check: () => api.get('/health')
};

export default api;
