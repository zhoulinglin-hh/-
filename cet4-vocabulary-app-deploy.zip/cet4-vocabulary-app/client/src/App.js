import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import Header from './components/Header';
import StudyMode from './components/StudyMode';
import ConfusableMode from './components/ConfusableMode';
import StatsMode from './components/StatsMode';
import { userAPI, studyAPI } from './utils/api';

function App() {
  const [activeTab, setActiveTab] = useState('study');
  const [userId, setUserId] = useState(null);
  const [progress, setProgress] = useState(null);
  const [loading, setLoading] = useState(true);
  
  // 初始化用户
  useEffect(() => {
    const initUser = async () => {
      try {
        const id = await userAPI.getOrCreateId();
        setUserId(id);
      } catch (err) {
        console.error('用户初始化失败:', err);
      }
    };
    
    initUser();
  }, []);
  
  // 加载进度
  useEffect(() => {
    if (!userId) return;
    
    const loadProgress = async () => {
      try {
        const response = await studyAPI.getQueue();
        if (response.success) {
          setProgress(response.progress);
        }
      } catch (err) {
        console.error('进度加载失败:', err);
      } finally {
        setLoading(false);
      }
    };
    
    loadProgress();
  }, [userId]);
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-50 to-blue-50">
        <motion.div 
          className="text-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
        >
          <div className="w-16 h-16 border-4 border-primary-200 border-t-primary-500 rounded-full animate-spin mx-auto mb-4"></div>
          <h1 className="text-xl font-bold text-gray-800">四级词汇背诵</h1>
          <p className="text-gray-500">正在初始化...</p>
        </motion.div>
      </div>
    );
  }
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-primary-50 via-blue-50 to-primary-50">
      <Header 
        activeTab={activeTab} 
        setActiveTab={setActiveTab}
        progress={progress}
      />
      
      <main className="pb-20">
        <AnimatePresence mode="wait">
          <motion.div
            key={activeTab}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {activeTab === 'study' && <StudyMode />}
            {activeTab === 'confusable' && <ConfusableMode />}
            {activeTab === 'stats' && <StatsMode />}
          </motion.div>
        </AnimatePresence>
      </main>
      
      {/* 底部信息 */}
      <footer className="fixed bottom-0 left-0 right-0 bg-white/80 backdrop-blur-sm border-t border-gray-200 py-2 px-4">
        <div className="max-w-4xl mx-auto flex items-center justify-between text-xs text-gray-400">
          <span>四级3500词背诵小程序</span>
          <span>熟词可斩 · 词根衍生 · 近反义词 · 例句 · 易错易混 · 考频观测</span>
        </div>
      </footer>
    </div>
  );
}

export default App;
